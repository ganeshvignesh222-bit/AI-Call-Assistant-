# ProGuard rules for AI Call Assistant
# ──────────────────────────────────────────────────────────────

# Keep Hilt-generated components
-keep class dagger.hilt.** { *; }
-keep @dagger.hilt.android.HiltAndroidApp class * { *; }
-keep @dagger.hilt.android.AndroidEntryPoint class * { *; }

# Keep Room entities and DAOs
-keep class com.saiganesh.callassistant.data.local.entities.** { *; }
-keep interface com.saiganesh.callassistant.data.local.dao.** { *; }

# Keep data classes used for JSON (Gson)
-keepclassmembers class * { @com.google.gson.annotations.SerializedName <fields>; }
-keep class com.google.gson.** { *; }

# Keep WorkManager workers
-keep class * extends androidx.work.Worker
-keep class * extends androidx.work.CoroutineWorker
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# Keep BroadcastReceivers (not obfuscated — referenced by system)
-keep class com.saiganesh.callassistant.service.CallReceiver { *; }
-keep class com.saiganesh.callassistant.service.BootReceiver { *; }

# Keep services
-keep class com.saiganesh.callassistant.service.CallAssistantService { *; }

# SQLCipher
-keep class net.sqlcipher.** { *; }
-dontwarn net.sqlcipher.**

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }

# Kotlin coroutines
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}

# Compose — keep reachable composable functions
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**
