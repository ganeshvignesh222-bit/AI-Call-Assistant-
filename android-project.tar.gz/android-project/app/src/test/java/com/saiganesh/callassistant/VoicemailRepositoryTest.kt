package com.saiganesh.callassistant

import com.saiganesh.callassistant.data.local.dao.VoicemailDao
import com.saiganesh.callassistant.data.local.entities.VoicemailEntity
import com.saiganesh.callassistant.data.repository.VoicemailRepository
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.mockito.kotlin.*

/**
 * VoicemailRepositoryTest — Unit tests for VoicemailRepository.
 *
 * Uses Mockito-Kotlin to mock the DAO layer.
 * No Android framework is needed — these run on the JVM.
 *
 * Add to build.gradle.kts to run these tests:
 *   testImplementation("org.mockito.kotlin:mockito-kotlin:5.1.0")
 *   testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
 */
class VoicemailRepositoryTest {

    private lateinit var dao: VoicemailDao
    private lateinit var repository: VoicemailRepository

    private val testVoicemail = VoicemailEntity(
        id = 1L,
        callerNumber = "+14155552671",
        callerName = "John Doe",
        recordingFilePath = "/data/recordings/test.m4a",
        durationMs = 45_000L,
        wasAiAnswered = true
    )

    @Before
    fun setup() {
        dao = mock()
        repository = VoicemailRepository(dao)
    }

    @Test
    fun `insertVoicemail returns generated ID`() = runTest {
        whenever(dao.insertVoicemail(any())).thenReturn(42L)

        val id = repository.insertVoicemail(testVoicemail)

        assertEquals(42L, id)
        verify(dao).insertVoicemail(testVoicemail)
    }

    @Test
    fun `markAsRead calls dao markAsRead`() = runTest {
        repository.markAsRead(1L)
        verify(dao).markAsRead(1L)
    }

    @Test
    fun `markAsUnread calls dao markAsUnread`() = runTest {
        repository.markAsUnread(1L)
        verify(dao).markAsUnread(1L)
    }

    @Test
    fun `setStarred calls dao setStarred with correct value`() = runTest {
        repository.setStarred(1L, true)
        verify(dao).setStarred(1L, true)

        repository.setStarred(1L, false)
        verify(dao).setStarred(1L, false)
    }

    @Test
    fun `updateTranscription saves transcription text`() = runTest {
        repository.updateTranscription(1L, "Hello this is a test transcription")
        verify(dao).updateTranscription(1L, "Hello this is a test transcription")
    }

    @Test
    fun `updateAiSummary saves AI summary`() = runTest {
        repository.updateAiSummary(1L, "John called to reschedule the meeting.")
        verify(dao).updateAiSummary(1L, "John called to reschedule the meeting.")
    }

    @Test
    fun `observeAllVoicemails returns flow from dao`() = runTest {
        val expected = listOf(testVoicemail)
        whenever(dao.observeAllVoicemails()).thenReturn(flowOf(expected))

        val flow = repository.observeAllVoicemails()
        flow.collect { voicemails ->
            assertEquals(expected, voicemails)
        }
    }

    @Test
    fun `deleteVoicemail deletes from dao`() = runTest {
        // Mock getAllRecordingPaths to avoid null pointer during delete
        whenever(dao.getVoicemailById(1L)).thenReturn(testVoicemail)

        repository.deleteVoicemail(testVoicemail)
        verify(dao).deleteVoicemail(testVoicemail)
    }

    @Test
    fun `searchVoicemails delegates to dao with query`() = runTest {
        val query = "John"
        whenever(dao.searchVoicemails(query)).thenReturn(flowOf(listOf(testVoicemail)))

        repository.searchVoicemails(query).collect { results ->
            assertEquals(1, results.size)
            assertEquals("John Doe", results.first().callerName)
        }
        verify(dao).searchVoicemails(query)
    }
}
