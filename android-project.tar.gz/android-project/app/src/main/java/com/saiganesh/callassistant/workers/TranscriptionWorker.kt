package com.saiganesh.callassistant.workers

import android.app.NotificationManager
import android.content.Context
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.saiganesh.callassistant.AICallAssistantApp
import com.saiganesh.callassistant.R
import com.saiganesh.callassistant.data.repository.SettingsRepository
import com.saiganesh.callassistant.data.repository.VoicemailRepository
import com.saiganesh.callassistant.utils.AiSummaryClient
import com.saiganesh.callassistant.utils.SpeechTranscriber
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/**
 * TranscriptionWorker — Background WorkManager job for transcription + AI summary.
 *
 * Runs after a voicemail recording is complete. Performs two tasks:
 * 1. Speech-to-text transcription of the recording
 * 2. AI-generated summary of the transcription
 *
 * Uses WorkManager (not a raw thread) because:
 * - Survives process death and device restart if work is still pending
 * - Respects battery optimization constraints
 * - Automatically retries on network failure (for cloud AI calls)
 * - Hilt injection is supported via @HiltWorker
 *
 * Constraints:
 * - Transcription: runs immediately (on-device SpeechRecognizer)
 * - AI summary: requires internet, deferred to when connected
 */
@HiltWorker
class TranscriptionWorker @AssistedInject constructor(
    @Assisted private val context: Context,
    @Assisted workerParams: WorkerParameters,
    private val voicemailRepository: VoicemailRepository,
    private val settingsRepository: SettingsRepository,
    private val speechTranscriber: SpeechTranscriber,
    private val aiSummaryClient: AiSummaryClient
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val voicemailId = inputData.getLong(KEY_VOICEMAIL_ID, -1)
        val filePath = inputData.getString(KEY_FILE_PATH) ?: return Result.failure()

        if (voicemailId < 0) {
            Log.e(TAG, "Invalid voicemail ID: $voicemailId")
            return Result.failure()
        }

        Log.i(TAG, "Starting transcription for voicemail $voicemailId")

        return try {
            val settings = settingsRepository.getSettings()

            // Step 1: Transcription
            if (settings.autoTranscribeEnabled) {
                val transcription = speechTranscriber.transcribe(filePath)
                if (transcription.isNotBlank()) {
                    voicemailRepository.updateTranscription(voicemailId, transcription)
                    Log.i(TAG, "Transcription saved for voicemail $voicemailId")

                    // Step 2: AI Summary (only if we have a transcription)
                    if (settings.aiSummaryEnabled && settingsRepository.hasAnyApiKey()) {
                        val summary = aiSummaryClient.summarize(transcription)
                        if (summary.isNotBlank()) {
                            voicemailRepository.updateAiSummary(voicemailId, summary)
                            showSummaryReadyNotification(voicemailId)
                            Log.i(TAG, "AI summary saved for voicemail $voicemailId")
                        }
                    }
                }
            }

            voicemailRepository.setProcessing(voicemailId, false)
            Result.success()

        } catch (e: Exception) {
            Log.e(TAG, "TranscriptionWorker failed for voicemail $voicemailId", e)
            voicemailRepository.setProcessing(voicemailId, false)

            // Retry up to 3 times with exponential backoff for network errors
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    private fun showSummaryReadyNotification(voicemailId: Long) {
        val notification = NotificationCompat.Builder(context, AICallAssistantApp.CHANNEL_AI_SUMMARY)
            .setSmallIcon(R.drawable.ic_ai)
            .setContentTitle("AI Summary Ready")
            .setContentText("Your voicemail has been summarized by AI")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(AICallAssistantApp.NOTIF_ID_AI_SUMMARY + voicemailId.toInt(), notification)
    }

    companion object {
        private const val TAG = "TranscriptionWorker"
        const val KEY_VOICEMAIL_ID = "voicemail_id"
        const val KEY_FILE_PATH = "file_path"

        /**
         * Enqueues the transcription job and returns the work ID string.
         *
         * Uses REPLACE policy so re-enqueuing the same voicemail
         * (e.g. retry) replaces the existing job.
         */
        fun enqueue(context: Context, voicemailId: Long, filePath: String): String {
            val workName = "transcription_$voicemailId"

            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = OneTimeWorkRequestBuilder<TranscriptionWorker>()
                .setInputData(
                    workDataOf(
                        KEY_VOICEMAIL_ID to voicemailId,
                        KEY_FILE_PATH to filePath
                    )
                )
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .addTag(workName)
                .build()

            WorkManager.getInstance(context)
                .enqueueUniqueWork(workName, ExistingWorkPolicy.REPLACE, request)

            return request.id.toString()
        }
    }
}
