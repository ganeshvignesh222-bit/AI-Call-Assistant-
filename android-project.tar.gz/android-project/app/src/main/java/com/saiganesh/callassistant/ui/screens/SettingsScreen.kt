package com.saiganesh.callassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.saiganesh.callassistant.viewmodel.SettingsViewModel

/**
 * SettingsScreen — Full settings page for AI Call Assistant.
 *
 * Sections:
 * 1. AI Auto-Answer — enable/disable, delay, target callers
 * 2. Greeting — custom TTS greeting text, voice settings
 * 3. Recording — max duration, silence timeout, beep
 * 4. AI Features — transcription, summaries, API key configuration
 * 5. Appearance — theme mode (system / light / dark)
 * 6. Privacy & Security — encryption, recording disclaimer
 * 7. Backup — cloud sync settings
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
        ) {
            // ── 1. AI Auto-Answer ────────────────────────────────────────────
            SettingsSection(title = "AI Auto-Answer") {
                SettingsToggleItem(
                    title = "Enable AI Auto-Answer",
                    subtitle = "AI handles calls and records voicemail automatically",
                    checked = settings.autoAnswerEnabled,
                    onCheckedChange = viewModel::setAutoAnswer,
                    icon = Icons.Default.SmartToy
                )

                if (settings.autoAnswerEnabled) {
                    SettingsSliderItem(
                        title = "Answer delay: ${settings.autoAnswerDelaySeconds}s",
                        subtitle = "Seconds before AI takes over (lets you answer first)",
                        value = settings.autoAnswerDelaySeconds.toFloat(),
                        range = 1f..10f,
                        steps = 8,
                        onValueChange = { viewModel.setAutoAnswerDelay(it.toInt()) },
                        icon = Icons.Default.Timer
                    )

                    SettingsToggleItem(
                        title = "Unknown callers only",
                        subtitle = "Contacts can still ring through normally",
                        checked = settings.onlyAnswerUnknownCallers,
                        onCheckedChange = viewModel::setOnlyUnknownCallers,
                        icon = Icons.Default.PersonOff
                    )
                }

                // Android limitation disclaimer
                SettingsInfoBanner(
                    text = "⚠️ Full auto-answer requires setting AI Call Assistant as your default Phone app. " +
                            "Without it, a notification with an 'AI Answer' button is shown instead."
                )
            }

            // ── 2. Greeting ──────────────────────────────────────────────────
            SettingsSection(title = "AI Greeting") {
                var editingGreeting by remember { mutableStateOf(false) }
                var greetingDraft by remember(settings.greetingText) {
                    mutableStateOf(settings.greetingText)
                }

                if (editingGreeting) {
                    OutlinedTextField(
                        value = greetingDraft,
                        onValueChange = { greetingDraft = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .heightIn(min = 100.dp),
                        label = { Text("Greeting message") },
                        supportingText = { Text("Spoken by AI when answering calls") }
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { editingGreeting = false; greetingDraft = settings.greetingText }) {
                            Text("Cancel")
                        }
                        Button(onClick = {
                            viewModel.setGreetingText(greetingDraft)
                            editingGreeting = false
                        }) {
                            Text("Save")
                        }
                    }
                } else {
                    SettingsClickItem(
                        title = "Custom Greeting",
                        subtitle = settings.greetingText.take(80) + if (settings.greetingText.length > 80) "..." else "",
                        icon = Icons.Default.RecordVoiceOver,
                        onClick = { editingGreeting = true }
                    )
                }

                SettingsSliderItem(
                    title = "Speech rate: ${"%.1f".format(settings.ttsSpeechRate)}x",
                    subtitle = "Speed of the AI voice",
                    value = settings.ttsSpeechRate,
                    range = 0.5f..2.0f,
                    onValueChange = viewModel::setTtsSpeechRate,
                    icon = Icons.Default.Speed
                )

                SettingsSliderItem(
                    title = "Voice pitch: ${"%.1f".format(settings.ttsPitch)}x",
                    subtitle = "Pitch of the AI voice",
                    value = settings.ttsPitch,
                    range = 0.5f..2.0f,
                    onValueChange = viewModel::setTtsPitch,
                    icon = Icons.Default.GraphicEq
                )

                SettingsToggleItem(
                    title = "Play beep before recording",
                    subtitle = "Required by law in many jurisdictions",
                    checked = settings.playBeepBeforeRecording,
                    onCheckedChange = viewModel::setPlayBeep,
                    icon = Icons.Default.NotificationsActive
                )
            }

            // ── 3. Recording ─────────────────────────────────────────────────
            SettingsSection(title = "Recording") {
                SettingsSliderItem(
                    title = "Max duration: ${settings.maxRecordingSeconds}s",
                    subtitle = "Recording stops automatically after this time",
                    value = settings.maxRecordingSeconds.toFloat(),
                    range = 30f..300f,
                    steps = 8,
                    onValueChange = { viewModel.setMaxRecordingSeconds(it.toInt()) },
                    icon = Icons.Default.Timelapse
                )

                SettingsInfoBanner(
                    text = "ℹ️ Android only records the microphone (caller's voice). " +
                            "Recording both sides of a call requires the default Phone app role, " +
                            "and is restricted on most devices since Android 10."
                )
            }

            // ── 4. AI Features ───────────────────────────────────────────────
            SettingsSection(title = "AI Features") {
                SettingsToggleItem(
                    title = "Auto-transcribe voicemails",
                    subtitle = "Convert speech to text after each recording",
                    checked = settings.autoTranscribeEnabled,
                    onCheckedChange = viewModel::setAutoTranscribe,
                    icon = Icons.Default.Transcribe
                )

                SettingsToggleItem(
                    title = "AI Summaries",
                    subtitle = "Generate short summaries using Gemini or OpenAI",
                    checked = settings.aiSummaryEnabled,
                    onCheckedChange = viewModel::setAiSummaryEnabled,
                    icon = Icons.Default.AutoAwesome
                )

                if (settings.aiSummaryEnabled) {
                    // AI provider selection
                    var showProviderDialog by remember { mutableStateOf(false) }
                    SettingsClickItem(
                        title = "AI Provider",
                        subtitle = settings.aiProvider.replaceFirstChar { it.uppercase() },
                        icon = Icons.Default.Cloud,
                        onClick = { showProviderDialog = true }
                    )
                    if (showProviderDialog) {
                        AlertDialog(
                            onDismissRequest = { showProviderDialog = false },
                            title = { Text("Select AI Provider") },
                            text = {
                                Column {
                                    listOf("gemini" to "Gemini (Google)", "openai" to "OpenAI (ChatGPT)").forEach { (id, label) ->
                                        RadioItem(
                                            label = label,
                                            selected = settings.aiProvider == id,
                                            onClick = { viewModel.setAiProvider(id); showProviderDialog = false }
                                        )
                                    }
                                }
                            },
                            confirmButton = {}
                        )
                    }

                    // API Key fields
                    ApiKeyField(
                        label = "Gemini API Key",
                        hint = "Get free key at aistudio.google.com",
                        hasKey = viewModel.hasGeminiKey.collectAsStateWithLifecycle().value,
                        onSave = viewModel::saveGeminiApiKey
                    )

                    ApiKeyField(
                        label = "OpenAI API Key",
                        hint = "Get key at platform.openai.com",
                        hasKey = viewModel.hasOpenAiKey.collectAsStateWithLifecycle().value,
                        onSave = viewModel::saveOpenAiApiKey
                    )
                }
            }

            // ── 5. Appearance ────────────────────────────────────────────────
            SettingsSection(title = "Appearance") {
                var showThemeDialog by remember { mutableStateOf(false) }
                SettingsClickItem(
                    title = "Theme",
                    subtitle = settings.themeMode.replaceFirstChar { it.uppercase() },
                    icon = Icons.Default.Palette,
                    onClick = { showThemeDialog = true }
                )
                if (showThemeDialog) {
                    AlertDialog(
                        onDismissRequest = { showThemeDialog = false },
                        title = { Text("Choose Theme") },
                        text = {
                            Column {
                                listOf("system" to "Follow System", "light" to "Light", "dark" to "Dark").forEach { (id, label) ->
                                    RadioItem(
                                        label = label,
                                        selected = settings.themeMode == id,
                                        onClick = { viewModel.setThemeMode(id); showThemeDialog = false }
                                    )
                                }
                            }
                        },
                        confirmButton = {}
                    )
                }
            }

            // ── 6. Privacy & Security ────────────────────────────────────────
            SettingsSection(title = "Privacy & Security") {
                SettingsToggleItem(
                    title = "Encrypt recordings",
                    subtitle = "Recordings are encrypted using AES-256-GCM",
                    checked = settings.encryptRecordings,
                    onCheckedChange = viewModel::setEncryptRecordings,
                    icon = Icons.Default.Lock
                )
                SettingsToggleItem(
                    title = "Recording disclaimer in greeting",
                    subtitle = "Recommended for two-party consent states (CA, FL, etc.)",
                    checked = settings.includeRecordingDisclaimer,
                    onCheckedChange = { viewModel.update { copy(includeRecordingDisclaimer = it) } },
                    icon = Icons.Default.GavelOutlined
                )
            }

            // ── 7. Backup ────────────────────────────────────────────────────
            SettingsSection(title = "Backup & Restore") {
                SettingsToggleItem(
                    title = "Cloud Backup",
                    subtitle = "Automatically back up voicemails to cloud",
                    checked = settings.cloudBackupEnabled,
                    onCheckedChange = viewModel::setCloudBackupEnabled,
                    icon = Icons.Default.CloudUpload
                )
                if (settings.cloudBackupEnabled) {
                    SettingsToggleItem(
                        title = "Wi-Fi only",
                        subtitle = "Only backup when connected to Wi-Fi",
                        checked = settings.backupWifiOnly,
                        onCheckedChange = { viewModel.update { copy(backupWifiOnly = it) } },
                        icon = Icons.Default.Wifi
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

// ─── Reusable Settings Components ──────────────────────────────────────────

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
        content()
        HorizontalDivider(modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun SettingsToggleItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    ListItem(
        headlineContent = { Text(title, style = MaterialTheme.typography.bodyLarge) },
        supportingContent = { Text(subtitle, style = MaterialTheme.typography.bodySmall) },
        leadingContent = {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        },
        trailingContent = {
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    )
}

@Composable
private fun SettingsClickItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle, style = MaterialTheme.typography.bodySmall) },
        leadingContent = {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        },
        trailingContent = {
            Icon(Icons.Default.ChevronRight, contentDescription = null)
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
private fun SettingsSliderItem(
    title: String,
    subtitle: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    steps: Int = 0
) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(24.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge)
                Text(subtitle, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            steps = steps,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 36.dp)
        )
    }
}

@Composable
private fun SettingsInfoBanner(text: String) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onTertiaryContainer,
            modifier = Modifier.padding(12.dp)
        )
    }
}

@Composable
private fun ApiKeyField(
    label: String,
    hint: String,
    hasKey: Boolean,
    onSave: (String) -> Unit
) {
    var editing by remember { mutableStateOf(false) }
    var keyDraft by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }

    if (editing) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
            OutlinedTextField(
                value = keyDraft,
                onValueChange = { keyDraft = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(label) },
                supportingText = { Text(hint) },
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { showKey = !showKey }) {
                        Icon(
                            if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = null
                        )
                    }
                },
                singleLine = true
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { editing = false; keyDraft = "" }) { Text("Cancel") }
                Button(onClick = {
                    if (keyDraft.isNotBlank()) onSave(keyDraft)
                    editing = false; keyDraft = ""
                }) { Text("Save") }
            }
        }
    } else {
        ListItem(
            headlineContent = { Text(label) },
            supportingContent = {
                Text(
                    if (hasKey) "API key configured ✓" else "Not configured — $hint",
                    color = if (hasKey) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            leadingContent = {
                Icon(
                    if (hasKey) Icons.Default.VpnKey else Icons.Default.VpnKeyOff,
                    contentDescription = null,
                    tint = if (hasKey) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            trailingContent = {
                TextButton(onClick = { editing = true }) {
                    Text(if (hasKey) "Change" else "Add")
                }
            }
        )
    }
}

@Composable
private fun RadioItem(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Spacer(modifier = Modifier.width(8.dp))
        Text(label)
    }
}

private fun androidx.compose.ui.Modifier.clickable(onClick: () -> Unit) =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
