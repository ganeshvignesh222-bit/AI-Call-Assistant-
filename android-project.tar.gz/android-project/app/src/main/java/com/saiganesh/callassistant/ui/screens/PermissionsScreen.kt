package com.saiganesh.callassistant.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.accompanist.permissions.*

/**
 * PermissionsScreen — Onboarding screen that explains and requests
 * all permissions required for full functionality.
 *
 * Each permission is listed with:
 * - What it does
 * - Why the app needs it
 * - Current grant status
 * - A request button (or "Open Settings" if permanently denied)
 *
 * Note: Android 10+ restricts several telephony permissions for
 * third-party apps. Limitations are explained inline.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun PermissionsScreen(onAllGranted: () -> Unit) {
    val context = LocalContext.current

    val permissionGroups = listOf(
        PermissionInfo(
            permission = Manifest.permission.READ_PHONE_STATE,
            title = "Phone State",
            description = "Detect when calls are incoming or ended",
            icon = Icons.Default.Phone,
            required = true
        ),
        PermissionInfo(
            permission = Manifest.permission.RECORD_AUDIO,
            title = "Microphone",
            description = "Record the caller's voicemail message",
            icon = Icons.Default.Mic,
            required = true
        ),
        PermissionInfo(
            permission = Manifest.permission.READ_CALL_LOG,
            title = "Call Log",
            description = "Match caller info and call history",
            icon = Icons.Default.History,
            required = false
        ),
        PermissionInfo(
            permission = Manifest.permission.ANSWER_PHONE_CALLS,
            title = "Answer Calls",
            description = "Auto-answer via the notification button. Full auto-answer requires setting this app as the default dialer.",
            icon = Icons.Default.CallEnd,
            required = false,
            limitation = "Limited on Android 10+ without default dialer role"
        )
    )

    val permissionStates = permissionGroups.map { info ->
        info to rememberPermissionState(info.permission)
    }

    val allRequired = permissionStates
        .filter { (info, _) -> info.required }
        .all { (_, state) -> state.status.isGranted }

    LaunchedEffect(allRequired) {
        if (allRequired) onAllGranted()
    }

    Scaffold { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                Icons.Default.Security,
                contentDescription = null,
                modifier = Modifier.size(64.dp).align(Alignment.CenterHorizontally),
                tint = MaterialTheme.colorScheme.primary
            )

            Text(
                text = "Permissions Required",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Text(
                text = "AI Call Assistant needs the following permissions to handle your calls:",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            permissionStates.forEach { (info, state) ->
                PermissionCard(
                    info = info,
                    isGranted = state.status.isGranted,
                    isPermanentlyDenied = state.status.shouldShowRationale.not() && !state.status.isGranted,
                    onRequest = { state.launchPermissionRequest() },
                    onOpenSettings = {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                        )
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onAllGranted,
                modifier = Modifier.fillMaxWidth(),
                enabled = allRequired
            ) {
                Text(if (allRequired) "Continue" else "Grant required permissions above")
            }
        }
    }
}

@Composable
private fun PermissionCard(
    info: PermissionInfo,
    isGranted: Boolean,
    isPermanentlyDenied: Boolean,
    onRequest: () -> Unit,
    onOpenSettings: () -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                info.icon,
                contentDescription = null,
                modifier = Modifier.size(32.dp),
                tint = if (isGranted) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant
            )

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = info.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (info.required) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = MaterialTheme.shapes.extraSmall
                        ) {
                            Text(
                                text = "Required",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Text(
                    text = info.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (info.limitation != null) {
                    Text(
                        text = info.limitation,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }

            when {
                isGranted -> Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = "Granted",
                    tint = MaterialTheme.colorScheme.primary
                )
                isPermanentlyDenied -> TextButton(onClick = onOpenSettings) {
                    Text("Settings")
                }
                else -> TextButton(onClick = onRequest) {
                    Text("Grant")
                }
            }
        }
    }
}

private data class PermissionInfo(
    val permission: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val required: Boolean,
    val limitation: String? = null
)
