package com.saiganesh.callassistant.data.local.dao

import androidx.room.*
import com.saiganesh.callassistant.data.local.entities.VoicemailEntity
import kotlinx.coroutines.flow.Flow

/**
 * VoicemailDao — Room Data Access Object for voicemail operations.
 *
 * All queries that power the UI return Flow<> so Compose can
 * automatically recompose when data changes without manual observation.
 *
 * Query optimisation notes:
 * - "ORDER BY timestamp DESC" puts newest voicemails first everywhere.
 * - FTS (Full-Text Search) would give better search performance at scale,
 *   but simple LIKE queries are sufficient for typical voicemail counts.
 */
@Dao
interface VoicemailDao {

    // ─── INSERT / UPDATE / DELETE ────────────────────────────────────────────

    /**
     * Insert a new voicemail. Returns the generated row ID.
     * OnConflict.REPLACE allows updating an existing row with the same ID.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVoicemail(voicemail: VoicemailEntity): Long

    /** Update all fields of an existing voicemail */
    @Update
    suspend fun updateVoicemail(voicemail: VoicemailEntity)

    /** Delete a specific voicemail (the caller must also delete the audio file) */
    @Delete
    suspend fun deleteVoicemail(voicemail: VoicemailEntity)

    /** Delete all voicemails — used in data wipe/reset */
    @Query("DELETE FROM voicemails")
    suspend fun deleteAllVoicemails()

    // ─── SINGLE ITEM QUERIES ─────────────────────────────────────────────────

    /** Observe a single voicemail by ID. Used in the detail screen. */
    @Query("SELECT * FROM voicemails WHERE id = :id")
    fun observeVoicemailById(id: Long): Flow<VoicemailEntity?>

    /** One-shot fetch (for background workers that don't observe UI) */
    @Query("SELECT * FROM voicemails WHERE id = :id")
    suspend fun getVoicemailById(id: Long): VoicemailEntity?

    // ─── LIST QUERIES ─────────────────────────────────────────────────────────

    /** All voicemails, newest first — powers the main Inbox screen */
    @Query("SELECT * FROM voicemails ORDER BY timestamp DESC")
    fun observeAllVoicemails(): Flow<List<VoicemailEntity>>

    /** All unread voicemails — used for badge counts */
    @Query("SELECT * FROM voicemails WHERE isRead = 0 ORDER BY timestamp DESC")
    fun observeUnreadVoicemails(): Flow<List<VoicemailEntity>>

    /** Starred voicemails */
    @Query("SELECT * FROM voicemails WHERE isStarred = 1 ORDER BY timestamp DESC")
    fun observeStarredVoicemails(): Flow<List<VoicemailEntity>>

    /** AI-answered calls only */
    @Query("SELECT * FROM voicemails WHERE wasAiAnswered = 1 ORDER BY timestamp DESC")
    fun observeAiAnsweredVoicemails(): Flow<List<VoicemailEntity>>

    // ─── SEARCH ──────────────────────────────────────────────────────────────

    /**
     * Search by caller name, number, transcription, or AI summary.
     * The % wildcards allow partial matching anywhere in the string.
     * Case-insensitive by default in SQLite (for ASCII characters).
     */
    @Query(
        """
        SELECT * FROM voicemails
        WHERE callerName LIKE '%' || :query || '%'
           OR callerNumber LIKE '%' || :query || '%'
           OR transcription LIKE '%' || :query || '%'
           OR aiSummary LIKE '%' || :query || '%'
        ORDER BY timestamp DESC
        """
    )
    fun searchVoicemails(query: String): Flow<List<VoicemailEntity>>

    // ─── DASHBOARD / STATISTICS ──────────────────────────────────────────────

    /** Total number of voicemails saved */
    @Query("SELECT COUNT(*) FROM voicemails")
    fun observeTotalCount(): Flow<Int>

    /** Number of unread voicemails */
    @Query("SELECT COUNT(*) FROM voicemails WHERE isRead = 0")
    fun observeUnreadCount(): Flow<Int>

    /** Number of AI-answered calls */
    @Query("SELECT COUNT(*) FROM voicemails WHERE wasAiAnswered = 1")
    fun observeAiAnsweredCount(): Flow<Int>

    /** Number of missed calls (callType = 3) */
    @Query("SELECT COUNT(*) FROM voicemails WHERE callType = 3")
    fun observeMissedCallCount(): Flow<Int>

    /** Number of voicemails with completed AI summaries */
    @Query("SELECT COUNT(*) FROM voicemails WHERE aiSummary IS NOT NULL AND aiSummary != ''")
    fun observeSummaryCount(): Flow<Int>

    /** Total storage used by all recordings in bytes */
    @Query("SELECT COALESCE(SUM(fileSizeBytes), 0) FROM voicemails")
    fun observeTotalStorageBytes(): Flow<Long>

    // ─── FIELD-LEVEL UPDATES ─────────────────────────────────────────────────
    // These targeted updates avoid loading the full entity just to change one field.

    @Query("UPDATE voicemails SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("UPDATE voicemails SET isRead = 0 WHERE id = :id")
    suspend fun markAsUnread(id: Long)

    @Query("UPDATE voicemails SET isStarred = :starred WHERE id = :id")
    suspend fun setStarred(id: Long, starred: Boolean)

    @Query("UPDATE voicemails SET transcription = :text WHERE id = :id")
    suspend fun updateTranscription(id: Long, text: String)

    @Query("UPDATE voicemails SET aiSummary = :summary WHERE id = :id")
    suspend fun updateAiSummary(id: Long, summary: String)

    @Query("UPDATE voicemails SET isProcessing = :processing WHERE id = :id")
    suspend fun setProcessing(id: Long, processing: Boolean)

    @Query("UPDATE voicemails SET isBackedUp = 1 WHERE id = :id")
    suspend fun markAsBackedUp(id: Long)

    @Query("UPDATE voicemails SET workId = :workId WHERE id = :id")
    suspend fun setWorkId(id: Long, workId: String)

    @Query("UPDATE voicemails SET durationMs = :durationMs, fileSizeBytes = :fileSize WHERE id = :id")
    suspend fun updateRecordingMeta(id: Long, durationMs: Long, fileSize: Long)

    // ─── CLEANUP ─────────────────────────────────────────────────────────────

    /** Get voicemails older than a given timestamp (for auto-cleanup) */
    @Query("SELECT * FROM voicemails WHERE timestamp < :beforeTimestamp")
    suspend fun getVoicemailsOlderThan(beforeTimestamp: Long): List<VoicemailEntity>

    /** Get all recording file paths — used for storage audit */
    @Query("SELECT recordingFilePath FROM voicemails")
    suspend fun getAllRecordingPaths(): List<String>
}
