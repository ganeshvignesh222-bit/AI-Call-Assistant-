package com.saiganesh.callassistant.di

import android.content.Context
import com.saiganesh.callassistant.data.local.AppDatabase
import com.saiganesh.callassistant.data.local.dao.SettingsDao
import com.saiganesh.callassistant.data.local.dao.VoicemailDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * AppModule — Hilt dependency injection module.
 *
 * Provides all singleton-scoped dependencies:
 * - AppDatabase (Room + SQLCipher encrypted)
 * - VoicemailDao
 * - SettingsDao
 *
 * Repositories, SpeechTranscriber, and AiSummaryClient use
 * @Inject constructor() so they self-bind without explicit @Provides.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideAppDatabase(
        @ApplicationContext context: Context
    ): AppDatabase = AppDatabase.getInstance(context)

    @Provides
    @Singleton
    fun provideVoicemailDao(database: AppDatabase): VoicemailDao =
        database.voicemailDao()

    @Provides
    @Singleton
    fun provideSettingsDao(database: AppDatabase): SettingsDao =
        database.settingsDao()
}
