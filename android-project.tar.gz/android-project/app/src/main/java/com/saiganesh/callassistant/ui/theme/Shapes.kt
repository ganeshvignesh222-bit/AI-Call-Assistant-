package com.saiganesh.callassistant.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/**
 * AppShapes — Material 3 shape scale.
 * Defines consistent corner radii across all UI components.
 */
val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),   // Chips, tooltips
    small = RoundedCornerShape(8.dp),         // Buttons, text fields
    medium = RoundedCornerShape(12.dp),       // Cards, dialogs
    large = RoundedCornerShape(16.dp),        // Bottom sheets, modals
    extraLarge = RoundedCornerShape(24.dp)    // FABs, full-screen sheets
)
