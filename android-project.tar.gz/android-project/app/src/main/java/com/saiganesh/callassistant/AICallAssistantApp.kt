package com.saiganesh.callassistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

/**
 * AICallAssistantApp — Application class
 *
 * Entry point for the entire app. Responsibilities:
 * 1. Hilt DI initialization (via @HiltAndroidApp)
 * 2. WorkManager configuration with Hilt worker injection
 * 3. Notification channel registration (required on Android 8+)
 *
 * All four notification channels are registered here so they are
 * always available when notifications are posted from any component.
 */
@HiltAndroidApp
class AICallAssistantApp : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    // WorkManager configuration with Hilt support
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    /**
     * Creates all notification channels required by the app.
     *
     * NotificationChannels MUST be created before posting any notification.
     * Creating a channel that already exists is a safe no-op.
     *
     * Channel hierarchy:
     * - CHANNEL_INCOMING_CALL: Highest importance — full-screen alert for incoming calls
     * - CHANNEL_VOICEMAIL: Default importance — new voicemail saved
     * - CHANNEL_RECORDING: Low importance — ongoing recording indicator
     * - CHANNEL_AI_SUMMARY: Default importance — AI summary or transcription ready
     */
    private fun createNotificationChannels() {
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channels = listOf(
            NotificationChannel(
                CHANNEL_INCOMING_CALL,
                "Incoming Call Detection",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts when an incoming call is detected by AI Call Assistant"
                enableLights(true)
                enableVibration(true)
                setShowBadge(true)
            },
            NotificationChannel(
                CHANNEL_VOICEMAIL,
                "New Voicemail",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notification when a new voicemail has been saved"
                setShowBadge(true)
            },
            NotificationChannel(
                CHANNEL_RECORDING,
                "Recording in Progress",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Persistent notification shown while recording is active"
                setShowBadge(false)
            },
            NotificationChannel(
                CHANNEL_AI_SUMMARY,
                "AI Summary Ready",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notification when AI transcription or summary is ready"
                setShowBadge(true)
            }
        )

        notificationManager.createNotificationChannels(channels)
    }

    companion object {
        // Notification channel IDs — referenced throughout the codebase
        const val CHANNEL_INCOMING_CALL = "channel_incoming_call"
        const val CHANNEL_VOICEMAIL = "channel_voicemail"
        const val CHANNEL_RECORDING = "channel_recording"
        const val CHANNEL_AI_SUMMARY = "channel_ai_summary"

        // Notification IDs
        const val NOTIF_ID_INCOMING_CALL = 1001
        const val NOTIF_ID_RECORDING = 1002
        const val NOTIF_ID_VOICEMAIL = 1003
        const val NOTIF_ID_AI_SUMMARY = 1004
    }
}
