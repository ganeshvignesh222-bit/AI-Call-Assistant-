package com.saiganesh.callassistant.data.repository

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.saiganesh.callassistant.data.local.dao.SettingsDao
import com.saiganesh.callassistant.data.local.entities.SettingsEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * SettingsRepository — manages user preferences and secure API key storage.
 *
 * Two storage mechanisms:
 * 1. Room (SettingsDao) — non-sensitive settings, observed via Flow
 * 2. EncryptedSharedPreferences — sensitive values like API keys
 *    (never stored in Room/SQLite for extra isolation)
 */
@Singleton
class SettingsRepository @Inject constructor(
    private val dao: SettingsDao,
    @ApplicationContext private val context: Context
) {

    // ─── Encrypted prefs for API keys ────────────────────────────────────────

    private val encryptedPrefs by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "secure_api_keys",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // ─── Settings (non-sensitive) ─────────────────────────────────────────────

    fun observeSettings(): Flow<SettingsEntity> =
        dao.observeSettings().map { it ?: SettingsEntity() }

    suspend fun getSettings(): SettingsEntity =
        dao.getSettings() ?: SettingsEntity()

    suspend fun updateSettings(settings: SettingsEntity) =
        dao.upsertSettings(settings)

    /** Called on first launch to insert default settings row */
    suspend fun initializeDefaultsIfNeeded() {
        if (dao.getSettings() == null) {
            dao.upsertSettings(SettingsEntity())
        }
    }

    // ─── API keys (stored in EncryptedSharedPreferences) ────────────────────

    fun saveGeminiApiKey(key: String) {
        encryptedPrefs.edit().putString(KEY_GEMINI_API_KEY, key).apply()
    }

    fun getGeminiApiKey(): String? =
        encryptedPrefs.getString(KEY_GEMINI_API_KEY, null)

    fun saveOpenAiApiKey(key: String) {
        encryptedPrefs.edit().putString(KEY_OPENAI_API_KEY, key).apply()
    }

    fun getOpenAiApiKey(): String? =
        encryptedPrefs.getString(KEY_OPENAI_API_KEY, null)

    fun clearApiKeys() {
        encryptedPrefs.edit()
            .remove(KEY_GEMINI_API_KEY)
            .remove(KEY_OPENAI_API_KEY)
            .apply()
    }

    fun hasAnyApiKey(): Boolean =
        getGeminiApiKey() != null || getOpenAiApiKey() != null

    companion object {
        private const val KEY_GEMINI_API_KEY = "gemini_api_key"
        private const val KEY_OPENAI_API_KEY = "openai_api_key"
    }
}
