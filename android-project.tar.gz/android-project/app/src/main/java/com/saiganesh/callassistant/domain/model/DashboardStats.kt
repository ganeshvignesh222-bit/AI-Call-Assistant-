package com.saiganesh.callassistant.domain.model

/**
 * DashboardStats — aggregated statistics shown on the Dashboard screen.
 *
 * Derived from multiple VoicemailDao flow queries combined in
 * VoicemailRepository.observeDashboardStats().
 */
data class DashboardStats(
    /** Total number of calls handled by the app */
    val totalCalls: Int = 0,

    /** Calls where callType == 3 (missed) */
    val missedCalls: Int = 0,

    /** Calls where wasAiAnswered == true */
    val aiAnsweredCalls: Int = 0,

    /** Total saved voicemails (same as totalCalls in this context) */
    val voicemails: Int = 0,

    /** Voicemails with a completed AI summary */
    val aiSummaries: Int = 0,

    /** Total disk space used by all recordings in bytes */
    val storageUsedBytes: Long = 0L,

    /** Number of unread voicemails (for badge display) */
    val unreadCount: Int = 0
) {
    /** Human-readable storage string, e.g. "12.4 MB" */
    val storageUsedFormatted: String
        get() = when {
            storageUsedBytes < 1024 -> "$storageUsedBytes B"
            storageUsedBytes < 1024 * 1024 -> "%.1f KB".format(storageUsedBytes / 1024.0)
            storageUsedBytes < 1024 * 1024 * 1024 -> "%.1f MB".format(storageUsedBytes / (1024.0 * 1024))
            else -> "%.2f GB".format(storageUsedBytes / (1024.0 * 1024 * 1024))
        }
}
