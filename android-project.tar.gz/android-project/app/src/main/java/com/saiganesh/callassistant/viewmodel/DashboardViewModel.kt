package com.saiganesh.callassistant.viewmodel

import androidx.lifecycle.ViewModel
import com.saiganesh.callassistant.data.repository.VoicemailRepository
import com.saiganesh.callassistant.domain.model.DashboardStats
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

/**
 * DashboardViewModel — Exposes aggregated stats for the Dashboard screen.
 *
 * Uses stateIn() to share a single upstream Flow across all collectors
 * (avoids re-querying the DB on each recomposition). SharingStarted.WhileSubscribed
 * cancels the upstream when the UI is not visible (saves resources).
 */
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val voicemailRepository: VoicemailRepository
) : ViewModel() {

    val stats: StateFlow<DashboardStats> = voicemailRepository
        .observeDashboardStats()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = DashboardStats()
        )
}
