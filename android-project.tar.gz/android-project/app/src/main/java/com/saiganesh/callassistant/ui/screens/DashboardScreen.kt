package com.saiganesh.callassistant.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.saiganesh.callassistant.domain.model.DashboardStats
import com.saiganesh.callassistant.viewmodel.DashboardViewModel

/**
 * DashboardScreen — Main home screen showing aggregated call statistics.
 *
 * Stats cards animate in with staggered delays for a polished entry.
 * Numbers count up with a smooth animation when data first loads.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onNavigateToInbox: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "AI Call Assistant",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Sai Ganesh",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNavigateToInbox,
                icon = { Icon(Icons.Default.Voicemail, contentDescription = null) },
                text = { Text("Voicemail Inbox") }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero banner
            HeroBanner(stats = stats)

            // Stats grid
            Text(
                text = "Overview",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            StatsGrid(stats = stats)

            // Storage card
            StorageCard(stats = stats)

            Spacer(modifier = Modifier.height(80.dp)) // FAB clearance
        }
    }
}

@Composable
private fun HeroBanner(stats: DashboardStats) {
    val gradientColors = listOf(
        MaterialTheme.colorScheme.primary,
        MaterialTheme.colorScheme.secondary
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.large)
            .background(Brush.linearGradient(gradientColors))
            .padding(24.dp)
    ) {
        Column {
            Text(
                text = "AI Active",
                style = MaterialTheme.typography.labelLarge,
                color = Color.White.copy(alpha = 0.8f)
            )
            Spacer(modifier = Modifier.height(4.dp))
            AnimatedCounter(
                count = stats.aiAnsweredCalls,
                style = MaterialTheme.typography.displayMedium.copy(
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            )
            Text(
                text = "calls handled by AI",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.7f)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Chip(
                    label = "${stats.unreadCount} unread",
                    icon = Icons.Default.MarkEmailUnread,
                    containerColor = Color.White.copy(alpha = 0.2f),
                    contentColor = Color.White
                )
                Chip(
                    label = "${stats.missedCalls} missed",
                    icon = Icons.Default.PhoneMissed,
                    containerColor = Color.White.copy(alpha = 0.2f),
                    contentColor = Color.White
                )
            }
        }
    }
}

@Composable
private fun StatsGrid(stats: DashboardStats) {
    // 2x3 grid of stat cards
    val cards = listOf(
        StatCardData(
            label = "Total Calls",
            value = stats.totalCalls,
            icon = Icons.Default.Phone,
            color = MaterialTheme.colorScheme.primary,
            delay = 0
        ),
        StatCardData(
            label = "Missed Calls",
            value = stats.missedCalls,
            icon = Icons.Default.PhoneMissed,
            color = Color(0xFFE53935),
            delay = 50
        ),
        StatCardData(
            label = "AI Answered",
            value = stats.aiAnsweredCalls,
            icon = Icons.Default.SmartToy,
            color = MaterialTheme.colorScheme.secondary,
            delay = 100
        ),
        StatCardData(
            label = "Voicemails",
            value = stats.voicemails,
            icon = Icons.Default.Voicemail,
            color = Color(0xFF7B1FA2),
            delay = 150
        ),
        StatCardData(
            label = "AI Summaries",
            value = stats.aiSummaries,
            icon = Icons.Default.AutoAwesome,
            color = Color(0xFFF57C00),
            delay = 200
        ),
        StatCardData(
            label = "Unread",
            value = stats.unreadCount,
            icon = Icons.Default.MarkEmailUnread,
            color = Color(0xFF00897B),
            delay = 250
        )
    )

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        cards.chunked(2).forEach { row ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                row.forEach { card ->
                    StatCard(
                        data = card,
                        modifier = Modifier.weight(1f)
                    )
                }
                // Fill remaining space if odd number of cards in last row
                if (row.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun StatCard(data: StatCardData, modifier: Modifier = Modifier) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(data.delay.toLong())
        visible = true
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(400)) + slideInVertically(tween(400)) { it / 2 },
        modifier = modifier
    ) {
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(MaterialTheme.shapes.small)
                        .background(data.color.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = data.icon,
                        contentDescription = null,
                        tint = data.color,
                        modifier = Modifier.size(20.dp)
                    )
                }
                AnimatedCounter(
                    count = data.value,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = data.label,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun StorageCard(stats: DashboardStats) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.tertiaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Storage,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onTertiaryContainer
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Storage Used",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = stats.storageUsedFormatted,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/** Smooth number count-up animation */
@Composable
private fun AnimatedCounter(count: Int, style: androidx.compose.ui.text.TextStyle) {
    val animatedCount by animateIntAsState(
        targetValue = count,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "counter"
    )
    Text(text = animatedCount.toString(), style = style)
}

@Composable
private fun Chip(
    label: String,
    icon: ImageVector,
    containerColor: Color,
    contentColor: Color
) {
    Row(
        modifier = Modifier
            .clip(MaterialTheme.shapes.extraLarge)
            .background(containerColor)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = contentColor, modifier = Modifier.size(14.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = contentColor)
    }
}

private data class StatCardData(
    val label: String,
    val value: Int,
    val icon: ImageVector,
    val color: Color,
    val delay: Int
)
