package com.saiganesh.callassistant.utils

import android.util.Log
import com.google.gson.Gson
import com.saiganesh.callassistant.data.repository.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * AiSummaryClient — Calls Gemini or OpenAI to generate voicemail summaries.
 *
 * Provider selection is read from SettingsRepository at call time.
 * API keys are stored in EncryptedSharedPreferences (never in plaintext).
 *
 * Gemini (recommended):
 * - Model: gemini-1.5-flash (fast, cheap, good for summarization)
 * - Free tier: 15 RPM, 1M tokens/day
 * - Get API key: https://aistudio.google.com/
 *
 * OpenAI:
 * - Model: gpt-4o-mini (fast, cost-effective)
 * - Pricing: $0.15/1M input tokens
 * - Get API key: https://platform.openai.com/
 */
@Singleton
class AiSummaryClient @Inject constructor(
    private val settingsRepository: SettingsRepository
) {

    private val gson = Gson()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Generates a concise AI summary of the voicemail transcription.
     *
     * Returns empty string if:
     * - No API key is configured
     * - The AI provider is unavailable
     * - The network request fails after retries
     *
     * The summary prompt is engineered to produce 2–3 sentence summaries
     * that highlight: who called, the reason, and any action needed.
     */
    suspend fun summarize(transcription: String): String = withContext(Dispatchers.IO) {
        if (transcription.isBlank()) return@withContext ""

        val settings = settingsRepository.getSettings()

        return@withContext try {
            when (settings.aiProvider) {
                "gemini" -> {
                    val apiKey = settingsRepository.getGeminiApiKey()
                        ?: return@withContext ""
                    summarizeWithGemini(transcription, apiKey)
                }
                "openai" -> {
                    val apiKey = settingsRepository.getOpenAiApiKey()
                        ?: return@withContext ""
                    summarizeWithOpenAi(transcription, apiKey)
                }
                else -> ""
            }
        } catch (e: Exception) {
            Log.e(TAG, "AI summary failed: ${e.message}")
            ""
        }
    }

    // ─── Gemini ───────────────────────────────────────────────────────────────

    private suspend fun summarizeWithGemini(transcription: String, apiKey: String): String {
        val prompt = buildSummaryPrompt(transcription)

        val requestBody = gson.toJson(
            mapOf(
                "contents" to listOf(
                    mapOf("parts" to listOf(mapOf("text" to prompt)))
                ),
                "generationConfig" to mapOf(
                    "maxOutputTokens" to 200,
                    "temperature" to 0.3
                )
            )
        )

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey")
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val body = response.body?.string() ?: return ""

        if (!response.isSuccessful) {
            Log.e(TAG, "Gemini error ${response.code}: $body")
            return ""
        }

        // Parse Gemini response: candidates[0].content.parts[0].text
        return try {
            val json = gson.fromJson(body, Map::class.java)
            @Suppress("UNCHECKED_CAST")
            val candidates = json["candidates"] as? List<Map<String, Any>> ?: return ""
            val content = candidates.firstOrNull()?.get("content") as? Map<String, Any> ?: return ""
            val parts = content["parts"] as? List<Map<String, Any>> ?: return ""
            parts.firstOrNull()?.get("text") as? String ?: ""
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse Gemini response: ${e.message}")
            ""
        }
    }

    // ─── OpenAI ───────────────────────────────────────────────────────────────

    private suspend fun summarizeWithOpenAi(transcription: String, apiKey: String): String {
        val prompt = buildSummaryPrompt(transcription)

        val requestBody = gson.toJson(
            mapOf(
                "model" to "gpt-4o-mini",
                "messages" to listOf(
                    mapOf("role" to "user", "content" to prompt)
                ),
                "max_tokens" to 200,
                "temperature" to 0.3
            )
        )

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val body = response.body?.string() ?: return ""

        if (!response.isSuccessful) {
            Log.e(TAG, "OpenAI error ${response.code}: $body")
            return ""
        }

        return try {
            val json = gson.fromJson(body, Map::class.java)
            @Suppress("UNCHECKED_CAST")
            val choices = json["choices"] as? List<Map<String, Any>> ?: return ""
            val message = choices.firstOrNull()?.get("message") as? Map<String, Any> ?: return ""
            message["content"] as? String ?: ""
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse OpenAI response: ${e.message}")
            ""
        }
    }

    // ─── Prompt Engineering ───────────────────────────────────────────────────

    private fun buildSummaryPrompt(transcription: String): String = """
        You are an AI assistant that summarizes voicemail messages for Sai Ganesh.
        
        Voicemail transcription:
        "$transcription"
        
        Write a concise 2-3 sentence summary that tells Sai Ganesh:
        1. Who called (if mentioned)
        2. The main reason for the call
        3. Any action required or urgency
        
        Be direct and professional. Do not include filler phrases.
    """.trimIndent()

    companion object {
        private const val TAG = "AiSummaryClient"
    }
}
