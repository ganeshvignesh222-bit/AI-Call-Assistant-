package com.saiganesh.callassistant.data.local.dao

import androidx.room.*
import com.saiganesh.callassistant.data.local.entities.SettingsEntity
import kotlinx.coroutines.flow.Flow

/**
 * SettingsDao — Room DAO for the single-row settings table.
 *
 * The settings table always contains exactly one row (id = 1).
 * Upsert (insert-or-replace) is used to initialise defaults on
 * first launch and update on subsequent changes.
 */
@Dao
interface SettingsDao {

    /** Observe settings reactively — UI auto-updates when settings change */
    @Query("SELECT * FROM settings WHERE id = 1")
    fun observeSettings(): Flow<SettingsEntity?>

    /** One-shot read — used in workers and services that don't observe */
    @Query("SELECT * FROM settings WHERE id = 1")
    suspend fun getSettings(): SettingsEntity?

    /** Insert or replace the entire settings row */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSettings(settings: SettingsEntity)

    // ─── Field-level updates for efficiency ─────────────────────────────────

    @Query("UPDATE settings SET autoAnswerEnabled = :enabled WHERE id = 1")
    suspend fun setAutoAnswerEnabled(enabled: Boolean)

    @Query("UPDATE settings SET greetingText = :text WHERE id = 1")
    suspend fun setGreetingText(text: String)

    @Query("UPDATE settings SET themeMode = :mode WHERE id = 1")
    suspend fun setThemeMode(mode: String)

    @Query("UPDATE settings SET aiSummaryEnabled = :enabled WHERE id = 1")
    suspend fun setAiSummaryEnabled(enabled: Boolean)

    @Query("UPDATE settings SET autoTranscribeEnabled = :enabled WHERE id = 1")
    suspend fun setAutoTranscribeEnabled(enabled: Boolean)

    @Query("UPDATE settings SET maxRecordingSeconds = :seconds WHERE id = 1")
    suspend fun setMaxRecordingSeconds(seconds: Int)
}
