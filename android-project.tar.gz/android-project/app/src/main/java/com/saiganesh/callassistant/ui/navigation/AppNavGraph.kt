package com.saiganesh.callassistant.ui.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.saiganesh.callassistant.ui.screens.*

/**
 * AppNavGraph — Jetpack Compose Navigation graph.
 *
 * Routes:
 * - "dashboard"               → Dashboard screen (home)
 * - "inbox"                   → Voicemail inbox
 * - "detail/{voicemailId}"    → Voicemail detail + player
 * - "settings"                → Settings screen
 * - "permissions"             → Permission rationale screen
 *
 * All transitions use enter/exit slide animations for a smooth,
 * native-feeling navigation experience at 60–120 FPS.
 *
 * @param initialVoicemailId  Deep-link from notification — if non-null,
 *                             navigates directly to the detail screen.
 */
@Composable
fun AppNavGraph(initialVoicemailId: Long? = null) {
    val navController = rememberNavController()

    // Determine start destination based on deep-link
    val startDestination = if (initialVoicemailId != null) {
        Routes.voicemailDetail(initialVoicemailId)
    } else {
        Routes.DASHBOARD
    }

    NavHost(
        navController = navController,
        startDestination = startDestination,
        enterTransition = {
            slideInHorizontally(
                initialOffsetX = { it },
                animationSpec = tween(300)
            ) + fadeIn(animationSpec = tween(300))
        },
        exitTransition = {
            slideOutHorizontally(
                targetOffsetX = { -it / 3 },
                animationSpec = tween(300)
            ) + fadeOut(animationSpec = tween(200))
        },
        popEnterTransition = {
            slideInHorizontally(
                initialOffsetX = { -it / 3 },
                animationSpec = tween(300)
            ) + fadeIn(animationSpec = tween(300))
        },
        popExitTransition = {
            slideOutHorizontally(
                targetOffsetX = { it },
                animationSpec = tween(300)
            ) + fadeOut(animationSpec = tween(200))
        }
    ) {
        composable(Routes.DASHBOARD) {
            DashboardScreen(
                onNavigateToInbox = { navController.navigate(Routes.INBOX) },
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(Routes.INBOX) {
            InboxScreen(
                onNavigateBack = { navController.popBackStack() },
                onNavigateToDetail = { id ->
                    navController.navigate(Routes.voicemailDetail(id))
                }
            )
        }

        composable(
            route = Routes.VOICEMAIL_DETAIL,
            arguments = listOf(navArgument("voicemailId") { type = NavType.LongType })
        ) { backStackEntry ->
            val voicemailId = backStackEntry.arguments?.getLong("voicemailId") ?: return@composable
            VoicemailDetailScreen(
                voicemailId = voicemailId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}

object Routes {
    const val DASHBOARD = "dashboard"
    const val INBOX = "inbox"
    const val VOICEMAIL_DETAIL = "detail/{voicemailId}"
    const val SETTINGS = "settings"

    fun voicemailDetail(id: Long) = "detail/$id"
}
