package com.saiganesh.callassistant.data.local

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.saiganesh.callassistant.data.local.dao.SettingsDao
import com.saiganesh.callassistant.data.local.dao.VoicemailDao
import com.saiganesh.callassistant.data.local.entities.SettingsEntity
import com.saiganesh.callassistant.data.local.entities.VoicemailEntity
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

/**
 * AppDatabase — Room database definition.
 *
 * Database encryption:
 * The passphrase is generated once and stored in EncryptedSharedPreferences
 * (backed by Android Keystore). This means:
 * - The DB is encrypted at rest using SQLCipher.
 * - The key is hardware-backed on devices with a Secure Enclave / StrongBox.
 * - Even rooted devices cannot read the raw SQLite file without the key.
 *
 * Migrations:
 * Destructive migration is disabled; explicit migrations are required.
 * Use addMigrations(MIGRATION_1_2, ...) for schema changes.
 *
 * Note on SQLCipher dependency: add to build.gradle.kts:
 *   implementation("net.zetetic:android-database-sqlcipher:4.5.4")
 *   implementation("androidx.sqlite:sqlite-ktx:2.4.0")
 */
@Database(
    entities = [VoicemailEntity::class, SettingsEntity::class],
    version = 1,
    exportSchema = true // Exports schema to /schemas for migration tracking
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun voicemailDao(): VoicemailDao
    abstract fun settingsDao(): SettingsDao

    companion object {

        private const val DB_NAME = "ai_call_assistant.db"
        private const val PREFS_NAME = "db_key_prefs"
        private const val KEY_DB_PASSPHRASE = "db_passphrase"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Returns the singleton database instance.
         *
         * On first call:
         * 1. Generates a random 32-byte passphrase.
         * 2. Stores it encrypted in EncryptedSharedPreferences.
         * 3. Builds the Room database with SQLCipher support factory.
         *
         * On subsequent calls: returns the cached instance.
         */
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(context: Context): AppDatabase {
            // Step 1: Get or create encrypted passphrase
            val passphrase = getOrCreatePassphrase(context)

            // Step 2: Create SQLCipher support factory
            val factory = SupportFactory(SQLiteDatabase.getBytes(passphrase.toCharArray()))

            // Step 3: Build Room database
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                DB_NAME
            )
                .openHelperFactory(factory)
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Pre-populate default settings on first launch
                        // This is handled by the SettingsRepository
                    }
                })
                // Never allow destructive migration in production
                .fallbackToDestructiveMigrationOnDowngrade()
                .build()
        }

        /**
         * Retrieves the database passphrase from EncryptedSharedPreferences.
         * If not found (first launch), generates a cryptographically random one.
         *
         * The passphrase is backed by Android Keystore (hardware-backed when available).
         */
        private fun getOrCreatePassphrase(context: Context): String {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            val encryptedPrefs = EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )

            return encryptedPrefs.getString(KEY_DB_PASSPHRASE, null)
                ?: generatePassphrase().also { newPassphrase ->
                    encryptedPrefs.edit()
                        .putString(KEY_DB_PASSPHRASE, newPassphrase)
                        .apply()
                }
        }

        /** Generates a 32-character random hex passphrase */
        private fun generatePassphrase(): String {
            val bytes = ByteArray(16)
            java.security.SecureRandom().nextBytes(bytes)
            return bytes.joinToString("") { "%02x".format(it) }
        }
    }
}
