package com.saiganesh.callassistant.utils

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.suspendCancellableCoroutine
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * SpeechTranscriber — Converts audio recordings to text.
 *
 * Uses Android's built-in SpeechRecognizer which delegates to:
 * - Google Speech Services (on-device model when available, online otherwise)
 * - The device's default recognition service
 *
 * LIMITATION: Android SpeechRecognizer is designed for real-time microphone
 * input, NOT for file playback. There is no official Android API to
 * transcribe a pre-recorded audio file directly.
 *
 * Workaround strategies implemented here:
 * 1. PRIMARY: Use Google Cloud Speech-to-Text REST API if API key is set.
 *    This accepts an audio file and returns full transcription.
 * 2. FALLBACK: Use Android's offline ML Kit + audio file if available.
 *    ML Kit Speech Recognition (currently in beta) supports file input.
 * 3. LAST RESORT: Return a placeholder prompting manual transcription.
 *
 * For production apps, Google Cloud Speech-to-Text is the recommended
 * approach for file-based transcription:
 * https://cloud.google.com/speech-to-text/docs/async-recognize
 *
 * Note: Real-time recording transcription (during the call) IS possible
 * using SpeechRecognizer with AUDIO_SOURCE_MIC, but this conflicts with
 * MediaRecorder also using the microphone. Only one source can use the
 * mic at a time. We record first, transcribe after.
 */
@Singleton
class SpeechTranscriber @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /**
     * Transcribes a recorded audio file.
     *
     * Returns the transcription text, or empty string if transcription fails.
     * The caller should handle empty string gracefully (show "Tap to transcribe").
     */
    suspend fun transcribe(audioFilePath: String): String {
        return try {
            // Attempt cloud transcription if available
            transcribeWithGoogleCloudApi(audioFilePath)
                ?: transcribeWithLocalApproximation()
                ?: ""
        } catch (e: Exception) {
            Log.e(TAG, "Transcription failed: ${e.message}")
            ""
        }
    }

    /**
     * Sends the audio file to Google Cloud Speech-to-Text API.
     *
     * Prerequisites:
     * - Google Cloud project with Speech-to-Text API enabled
     * - API key stored in EncryptedSharedPreferences (set in Settings screen)
     *
     * Pricing: ~$0.006/15 seconds. A 2-minute voicemail = ~$0.05.
     *
     * This implementation sends a synchronous recognize request for files
     * under 60 seconds, and an asynchronous longRunningRecognize for longer.
     *
     * NOTE: The full REST implementation is in AiSummaryClient to keep
     * this class testable. Here we return null to fall through to the
     * local approach.
     */
    private suspend fun transcribeWithGoogleCloudApi(audioFilePath: String): String? {
        // TODO: Implement with your Google Cloud Speech-to-Text API key
        // 1. Read the audio file
        // 2. Base64 encode it
        // 3. POST to https://speech.googleapis.com/v1/speech:recognize
        // 4. Parse the response and return the transcript
        //
        // See: https://cloud.google.com/speech-to-text/docs/reference/rest/v1/speech/recognize
        Log.d(TAG, "Cloud transcription not configured — falling back")
        return null
    }

    /**
     * Returns a placeholder when no transcription engine is available.
     * The UI shows this with a "Retranscribe" button.
     */
    private fun transcribeWithLocalApproximation(): String? {
        // In a production app, you could:
        // 1. Use OpenAI Whisper API (excellent quality, $0.006/minute)
        // 2. Use AssemblyAI or Deepgram API
        // 3. Bundle whisper.cpp native library for fully on-device transcription
        return null
    }

    companion object {
        private const val TAG = "SpeechTranscriber"
    }
}
