package com.saiganesh.callassistant.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.saiganesh.callassistant.data.local.entities.VoicemailEntity
import com.saiganesh.callassistant.data.repository.VoicemailRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * VoicemailViewModel — Manages the voicemail inbox screen state.
 *
 * Handles:
 * - Listing all voicemails (newest first)
 * - Search/filter with debounce
 * - Tab filter: All / Unread / Starred / AI Answered
 * - Delete, star, mark-read operations
 */
@HiltViewModel
class VoicemailViewModel @Inject constructor(
    private val voicemailRepository: VoicemailRepository
) : ViewModel() {

    // ─── Search ──────────────────────────────────────────────────────────────

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun setSearchQuery(query: String) { _searchQuery.value = query }

    // ─── Filter tab ──────────────────────────────────────────────────────────

    enum class Filter { ALL, UNREAD, STARRED, AI_ANSWERED }

    private val _activeFilter = MutableStateFlow(Filter.ALL)
    val activeFilter: StateFlow<Filter> = _activeFilter.asStateFlow()

    fun setFilter(filter: Filter) { _activeFilter.value = filter }

    // ─── Voicemail list — derived from search + filter ───────────────────────

    @OptIn(ExperimentalCoroutinesApi::class)
    val voicemails: StateFlow<List<VoicemailEntity>> = combine(
        _searchQuery,
        _activeFilter
    ) { query, filter -> Pair(query, filter) }
        .flatMapLatest { (query, filter) ->
            if (query.isNotBlank()) {
                voicemailRepository.searchVoicemails(query)
            } else {
                when (filter) {
                    Filter.ALL -> voicemailRepository.observeAllVoicemails()
                    Filter.UNREAD -> voicemailRepository.observeUnreadVoicemails()
                    Filter.STARRED -> voicemailRepository.observeStarredVoicemails()
                    Filter.AI_ANSWERED -> voicemailRepository.observeAiAnsweredVoicemails()
                }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    // ─── Unread badge count ───────────────────────────────────────────────────

    val unreadCount: StateFlow<Int> = voicemailRepository
        .observeAllVoicemails()
        .map { list -> list.count { !it.isRead } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    // ─── Detail — selected voicemail ─────────────────────────────────────────

    private val _selectedId = MutableStateFlow<Long?>(null)

    val selectedVoicemail: StateFlow<VoicemailEntity?> = _selectedId
        .flatMapLatest { id ->
            if (id != null) voicemailRepository.observeVoicemailById(id)
            else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun selectVoicemail(id: Long) {
        _selectedId.value = id
        markAsRead(id)
    }

    fun clearSelection() { _selectedId.value = null }

    // ─── Actions ─────────────────────────────────────────────────────────────

    fun markAsRead(id: Long) = viewModelScope.launch {
        voicemailRepository.markAsRead(id)
    }

    fun markAsUnread(id: Long) = viewModelScope.launch {
        voicemailRepository.markAsUnread(id)
    }

    fun toggleStar(id: Long, currentlyStarred: Boolean) = viewModelScope.launch {
        voicemailRepository.setStarred(id, !currentlyStarred)
    }

    fun deleteVoicemail(voicemail: VoicemailEntity) = viewModelScope.launch {
        voicemailRepository.deleteVoicemail(voicemail)
    }

    fun deleteAll() = viewModelScope.launch {
        voicemailRepository.deleteAll()
    }
}
