package com.saiganesh.callassistant.data.repository

import com.saiganesh.callassistant.data.local.dao.VoicemailDao
import com.saiganesh.callassistant.data.local.entities.VoicemailEntity
import com.saiganesh.callassistant.domain.model.DashboardStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * VoicemailRepository — Single source of truth for voicemail data.
 *
 * Follows Repository pattern: ViewModels depend on this interface,
 * not directly on the DAO or network layer. This makes testing easy
 * (inject a fake repository in unit tests).
 *
 * File deletion responsibility:
 * When a voicemail is deleted, this repository also deletes the
 * corresponding audio file from disk to prevent orphaned files.
 */
@Singleton
class VoicemailRepository @Inject constructor(
    private val dao: VoicemailDao
) {

    // ─── Read ────────────────────────────────────────────────────────────────

    fun observeAllVoicemails(): Flow<List<VoicemailEntity>> =
        dao.observeAllVoicemails()

    fun observeUnreadVoicemails(): Flow<List<VoicemailEntity>> =
        dao.observeUnreadVoicemails()

    fun observeStarredVoicemails(): Flow<List<VoicemailEntity>> =
        dao.observeStarredVoicemails()

    fun observeAiAnsweredVoicemails(): Flow<List<VoicemailEntity>> =
        dao.observeAiAnsweredVoicemails()

    fun observeVoicemailById(id: Long): Flow<VoicemailEntity?> =
        dao.observeVoicemailById(id)

    suspend fun getVoicemailById(id: Long): VoicemailEntity? =
        dao.getVoicemailById(id)

    fun searchVoicemails(query: String): Flow<List<VoicemailEntity>> =
        dao.searchVoicemails(query)

    // ─── Dashboard stats — combined from multiple DAO flows ──────────────────

    fun observeDashboardStats(): Flow<DashboardStats> = combine(
        dao.observeTotalCount(),
        dao.observeUnreadCount(),
        dao.observeAiAnsweredCount(),
        dao.observeMissedCallCount(),
        dao.observeSummaryCount(),
        dao.observeTotalStorageBytes()
    ) { total, unread, aiAnswered, missed, summaries, storageByes ->
        DashboardStats(
            totalCalls = total,
            missedCalls = missed,
            aiAnsweredCalls = aiAnswered,
            voicemails = total,
            aiSummaries = summaries,
            storageUsedBytes = storageByes,
            unreadCount = unread
        )
    }

    // ─── Write ───────────────────────────────────────────────────────────────

    suspend fun insertVoicemail(voicemail: VoicemailEntity): Long =
        dao.insertVoicemail(voicemail)

    suspend fun updateVoicemail(voicemail: VoicemailEntity) =
        dao.updateVoicemail(voicemail)

    /**
     * Delete a voicemail and its associated recording file.
     *
     * File deletion is best-effort — if the file was already removed
     * (e.g. by the user via a file manager), the DB row is still deleted.
     */
    suspend fun deleteVoicemail(voicemail: VoicemailEntity) {
        // Delete audio file from disk first
        runCatching {
            val file = File(voicemail.recordingFilePath)
            if (file.exists()) file.delete()
        }
        dao.deleteVoicemail(voicemail)
    }

    suspend fun deleteVoicemailById(id: Long) {
        val voicemail = dao.getVoicemailById(id) ?: return
        deleteVoicemail(voicemail)
    }

    suspend fun deleteAll() {
        // Delete all audio files first
        runCatching {
            dao.getAllRecordingPaths().forEach { path ->
                File(path).takeIf { it.exists() }?.delete()
            }
        }
        dao.deleteAllVoicemails()
    }

    // ─── Field updates ───────────────────────────────────────────────────────

    suspend fun markAsRead(id: Long) = dao.markAsRead(id)
    suspend fun markAsUnread(id: Long) = dao.markAsUnread(id)
    suspend fun setStarred(id: Long, starred: Boolean) = dao.setStarred(id, starred)
    suspend fun updateTranscription(id: Long, text: String) = dao.updateTranscription(id, text)
    suspend fun updateAiSummary(id: Long, summary: String) = dao.updateAiSummary(id, summary)
    suspend fun setProcessing(id: Long, processing: Boolean) = dao.setProcessing(id, processing)
    suspend fun setWorkId(id: Long, workId: String) = dao.setWorkId(id, workId)
    suspend fun updateRecordingMeta(id: Long, durationMs: Long, fileSize: Long) =
        dao.updateRecordingMeta(id, durationMs, fileSize)
}
