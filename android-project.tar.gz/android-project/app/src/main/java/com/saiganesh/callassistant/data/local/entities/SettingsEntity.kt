package com.saiganesh.callassistant.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * SettingsEntity — Stores all user-configurable settings.
 *
 * Stored as a single row (id = 1) using Room. Settings are also
 * mirrored to DataStore for reactive UI observation.
 *
 * Design note: A single-row settings table is simpler than key-value
 * pairs when settings are strongly typed and co-read together.
 */
@Entity(tableName = "settings")
data class SettingsEntity(

    @PrimaryKey
    val id: Int = 1, // Always a single row

    // ─── AUTO-ANSWER ────────────────────────────────────────────────────────

    /**
     * Whether AI auto-answer is enabled.
     * When true, the app attempts to answer calls and play the AI greeting.
     *
     * LIMITATION: On Android 10+, auto-answering without being the default
     * dialer is unreliable. A notification with a prominent "AI Answer" button
     * is shown as an alternative.
     */
    val autoAnswerEnabled: Boolean = false,

    /**
     * Delay in seconds before the AI auto-answers the call.
     * Range: 1–10 seconds. Default: 3 seconds.
     * Allows the user to answer normally before AI takes over.
     */
    val autoAnswerDelaySeconds: Int = 3,

    // ─── GREETING ───────────────────────────────────────────────────────────

    /**
     * Custom AI greeting text spoken via TextToSpeech.
     * The default greeting mentions Sai Ganesh by name.
     */
    val greetingText: String = "Hello! Sai Ganesh is busy right now and will call you later. " +
            "If you'd like to leave a message, please speak after the beep. " +
            "This conversation may be recorded.",

    /**
     * TTS speech rate. 1.0 = normal speed.
     * Range: 0.5 (slow) to 2.0 (fast).
     */
    val ttsSpeechRate: Float = 1.0f,

    /**
     * TTS pitch. 1.0 = normal pitch.
     * Range: 0.5 (low) to 2.0 (high).
     */
    val ttsPitch: Float = 1.0f,

    /**
     * BCP 47 language tag for the TTS engine.
     * Examples: "en-US", "hi-IN", "te-IN"
     */
    val ttsLanguage: String = "en-US",

    // ─── RECORDING ──────────────────────────────────────────────────────────

    /**
     * Maximum recording duration in seconds.
     * Recording stops automatically if the caller hasn't hung up.
     * Default: 120 seconds (2 minutes).
     */
    val maxRecordingSeconds: Int = 120,

    /**
     * Silence timeout in seconds — recording stops if no audio detected.
     * Default: 10 seconds of silence.
     */
    val silenceTimeoutSeconds: Int = 10,

    /**
     * Whether to play a beep sound before recording starts.
     * Informing the caller that they're being recorded is required
     * by law in many jurisdictions (two-party consent states).
     */
    val playBeepBeforeRecording: Boolean = true,

    // ─── TRANSCRIPTION ──────────────────────────────────────────────────────

    /** Whether to auto-transcribe recordings using SpeechRecognizer */
    val autoTranscribeEnabled: Boolean = true,

    /**
     * Whether to use cloud transcription (better accuracy but requires internet).
     * When false, uses on-device Android SpeechRecognizer (offline, lower accuracy).
     */
    val useCloudTranscription: Boolean = false,

    // ─── AI SUMMARY ─────────────────────────────────────────────────────────

    /** Whether to generate AI summaries using Gemini/OpenAI */
    val aiSummaryEnabled: Boolean = true,

    /**
     * AI provider: "gemini" or "openai"
     * The API key is stored securely in EncryptedSharedPreferences,
     * NOT in this table.
     */
    val aiProvider: String = "gemini",

    // ─── NOTIFICATIONS ───────────────────────────────────────────────────────

    /** Notify when a new voicemail is saved */
    val notifyOnVoicemail: Boolean = true,

    /** Notify when AI summary is ready */
    val notifyOnSummary: Boolean = true,

    // ─── APPEARANCE ──────────────────────────────────────────────────────────

    /**
     * Theme mode: "system", "light", or "dark"
     */
    val themeMode: String = "system",

    // ─── BACKUP ──────────────────────────────────────────────────────────────

    /** Whether automatic cloud backup is enabled */
    val cloudBackupEnabled: Boolean = false,

    /** Whether to backup over Wi-Fi only (not mobile data) */
    val backupWifiOnly: Boolean = true,

    // ─── PRIVACY ─────────────────────────────────────────────────────────────

    /** Whether recordings are encrypted at rest */
    val encryptRecordings: Boolean = true,

    /**
     * Whether to show the recording disclaimer in the greeting.
     * Strongly recommended in two-party consent jurisdictions (CA, FL, etc.).
     */
    val includeRecordingDisclaimer: Boolean = true,

    // ─── FILTER ──────────────────────────────────────────────────────────────

    /**
     * Whether to only AI-answer calls from unknown numbers
     * (not in contacts). Known contacts ring normally.
     */
    val onlyAnswerUnknownCallers: Boolean = false,

    /** List of phone numbers to always block (comma-separated) */
    val blockedNumbers: String = "",

    /** List of phone numbers to always allow through (comma-separated) */
    val allowedNumbers: String = ""
)
