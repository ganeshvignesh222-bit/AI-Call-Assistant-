package com.saiganesh.callassistant.service

import android.app.*
import android.content.Intent
import android.media.*
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import com.saiganesh.callassistant.AICallAssistantApp
import com.saiganesh.callassistant.R
import com.saiganesh.callassistant.data.local.entities.VoicemailEntity
import com.saiganesh.callassistant.data.repository.SettingsRepository
import com.saiganesh.callassistant.data.repository.VoicemailRepository
import com.saiganesh.callassistant.ui.MainActivity
import com.saiganesh.callassistant.workers.TranscriptionWorker
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

/**
 * CallAssistantService — Foreground service that handles the core AI call flow.
 *
 * ══════════════════════════════════════════════════════════════
 * ANDROID API LIMITATIONS — READ BEFORE MODIFYING
 * ══════════════════════════════════════════════════════════════
 *
 * 1. AUDIO INJECTION INTO ACTIVE CALL (NOT POSSIBLE):
 *    Android has no public API to play audio INTO the telephone network
 *    stream. The TTS greeting plays through the device loudspeaker so
 *    the caller can hear it, but it is NOT injected into the call audio
 *    path. The caller hears it only if the call is on speaker mode.
 *
 *    Alternative: The user must put the call on speaker or use a headset.
 *    The app switches audio mode to MODE_IN_COMMUNICATION and routes to
 *    STREAM_VOICE_CALL as the nearest available option, but this still
 *    does not inject into the telephony stack.
 *
 * 2. AUTO-ANSWERING (PARTIALLY RESTRICTED):
 *    TelecomManager.acceptRingingCall() requires the ANSWER_PHONE_CALLS
 *    permission AND requires the app to be the default Phone app on
 *    Android 10+. As a third-party app:
 *    - We attempt acceptRingingCall() if we have the permission.
 *    - If rejected (SecurityException), we show a notification with
 *      a manual "AI Answer" button instead.
 *    - The user can set this app as the default dialer to unlock
 *      full auto-answer functionality.
 *
 * 3. RECORDING BOTH SIDES (NOT POSSIBLE on Android 10+):
 *    MediaRecorder records ONLY the microphone (caller's voice coming
 *    through the speaker). The remote party's audio cannot be captured
 *    from the telephony stack. Some OEM ROMs (Samsung, Xiaomi) provide
 *    proprietary APIs for this, but we cannot use them portably.
 *    Result: recordings contain only the caller's voice, not Sai Ganesh.
 *
 * 4. FOREGROUND SERVICE TYPE (Android 14+):
 *    Must declare foregroundServiceType="microphone|phoneCall" in the
 *    manifest to use the microphone in a foreground service on API 34+.
 *
 * ══════════════════════════════════════════════════════════════
 * CALL FLOW (when auto-answer succeeds):
 * ══════════════════════════════════════════════════════════════
 * 1. Incoming call detected → startForegroundService()
 * 2. Show foreground notification (recording in progress)
 * 3. Attempt to accept the call via TelecomManager
 * 4. Switch audio to speaker/in-communication mode
 * 5. Play AI greeting via TextToSpeech
 * 6. Play beep sound
 * 7. Start MediaRecorder (microphone only)
 * 8. Record until: caller hangs up OR silence timeout OR max duration
 * 9. Stop MediaRecorder, finalize file
 * 10. Save VoicemailEntity to Room database
 * 11. Show "new voicemail" notification
 * 12. Enqueue TranscriptionWorker (WorkManager background job)
 * 13. Stop foreground service
 */
@AndroidEntryPoint
class CallAssistantService : Service() {

    @Inject
    lateinit var voicemailRepository: VoicemailRepository

    @Inject
    lateinit var settingsRepository: SettingsRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var tts: TextToSpeech? = null
    private var mediaRecorder: MediaRecorder? = null
    private var currentVoicemailId: Long = -1
    private var recordingFile: File? = null
    private var recordingStartTime: Long = 0L

    // Silence detection handler
    private val silenceHandler = Handler(Looper.getMainLooper())
    private var silenceRunnable: Runnable? = null

    // Max duration timeout
    private val maxDurationHandler = Handler(Looper.getMainLooper())
    private var maxDurationRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        initTextToSpeech()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HANDLE_INCOMING_CALL -> {
                val callerNumber = intent.getStringExtra(EXTRA_CALLER_NUMBER) ?: "Unknown"
                startForeground(
                    AICallAssistantApp.NOTIF_ID_RECORDING,
                    buildRecordingNotification(callerNumber)
                )
                serviceScope.launch {
                    handleIncomingCall(callerNumber)
                }
            }
            ACTION_SHOW_NOTIFICATION_ONLY -> {
                val callerNumber = intent.getStringExtra(EXTRA_CALLER_NUMBER) ?: "Unknown"
                startForeground(
                    AICallAssistantApp.NOTIF_ID_INCOMING_CALL,
                    buildIncomingCallNotification(callerNumber)
                )
            }
            ACTION_CALL_ENDED -> {
                finalizeRecording()
            }
            ACTION_AI_ANSWER_TAPPED -> {
                val callerNumber = intent.getStringExtra(EXTRA_CALLER_NUMBER) ?: "Unknown"
                serviceScope.launch { handleIncomingCall(callerNumber) }
            }
        }
        return START_STICKY
    }

    // ─── Core Call Handling ──────────────────────────────────────────────────

    private suspend fun handleIncomingCall(callerNumber: String) {
        val settings = settingsRepository.getSettings()

        // Delay before AI takes over (gives user time to answer manually)
        delay(settings.autoAnswerDelaySeconds * 1000L)

        // Attempt to auto-answer the call
        attemptAutoAnswer()

        // Switch audio to speaker so TTS is audible to the caller
        setAudioToSpeaker()

        // Wait for TTS to be ready
        delay(500)

        // Play AI greeting
        playGreeting(settings.greetingText) {
            // Callback when greeting finishes
            if (settings.playBeepBeforeRecording) {
                playBeep {
                    serviceScope.launch {
                        startRecording(callerNumber, settings)
                    }
                }
            } else {
                serviceScope.launch {
                    startRecording(callerNumber, settings)
                }
            }
        }
    }

    /**
     * Attempts to accept the ringing call programmatically.
     *
     * This requires ANSWER_PHONE_CALLS permission AND default dialer status
     * on Android 10+. A SecurityException is caught gracefully.
     */
    private fun attemptAutoAnswer() {
        try {
            val telecomManager = getSystemService(TELECOM_SERVICE) as? android.telecom.TelecomManager
            if (checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                telecomManager?.acceptRingingCall()
                Log.i(TAG, "Auto-answer attempted via TelecomManager")
            }
        } catch (e: SecurityException) {
            // Expected on Android 10+ without default dialer status
            Log.w(TAG, "Auto-answer rejected (not default dialer): ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Auto-answer failed: ${e.message}")
        }
    }

    /**
     * Routes audio to the loudspeaker so TTS is audible during the call.
     *
     * LIMITATION: This routes the TTS to the speaker, but the audio is NOT
     * injected into the telephony network path. The remote caller hears
     * the greeting only if the call is on speaker or via mic pick-up.
     */
    private fun setAudioToSpeaker() {
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = true
    }

    // ─── TextToSpeech ────────────────────────────────────────────────────────

    private fun initTextToSpeech() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                Log.i(TAG, "TTS initialized successfully")
            } else {
                Log.e(TAG, "TTS initialization failed with status: $status")
            }
        }
    }

    private fun playGreeting(text: String, onComplete: () -> Unit) {
        tts?.let { engine ->
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == UTTERANCE_ID_GREETING) onComplete()
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    Log.e(TAG, "TTS error for utterance: $utteranceId")
                    onComplete() // Continue even if TTS fails
                }
            })

            val params = Bundle().apply {
                putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_VOICE_CALL)
            }
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, UTTERANCE_ID_GREETING)
        } ?: onComplete()
    }

    /** Plays the beep tone using ToneGenerator */
    private fun playBeep(onComplete: () -> Unit) {
        try {
            val toneGenerator = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 80)
            toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP, 800)
            Handler(Looper.getMainLooper()).postDelayed({
                toneGenerator.release()
                onComplete()
            }, 1000)
        } catch (e: Exception) {
            Log.e(TAG, "Beep playback failed: ${e.message}")
            onComplete()
        }
    }

    // ─── Recording ───────────────────────────────────────────────────────────

    private suspend fun startRecording(
        callerNumber: String,
        settings: com.saiganesh.callassistant.data.local.entities.SettingsEntity
    ) {
        // Create the recording file in app-private storage
        val recordingsDir = File(getExternalFilesDir(null), "recordings").also { it.mkdirs() }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(recordingsDir, "voicemail_${timestamp}.m4a")
        recordingFile = file

        // Pre-insert DB row so we have an ID for the WorkManager job
        val voicemailId = voicemailRepository.insertVoicemail(
            VoicemailEntity(
                callerNumber = callerNumber,
                recordingFilePath = file.absolutePath,
                wasAiAnswered = true,
                isProcessing = true,
                timestamp = System.currentTimeMillis()
            )
        )
        currentVoicemailId = voicemailId
        recordingStartTime = System.currentTimeMillis()

        try {
            mediaRecorder = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }).apply {
                // AUDIO_SOURCE_MIC records the microphone only.
                // LIMITATION: Cannot record the remote party's audio from telephony stack.
                // AUDIO_SOURCE_VOICE_COMMUNICATION is designed for VoIP but still only
                // captures the local microphone in a standard phone call context.
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(128000)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }

            Log.i(TAG, "Recording started: ${file.absolutePath}")

            // Set up max duration timeout
            val maxMs = settings.maxRecordingSeconds * 1000L
            maxDurationRunnable = Runnable {
                Log.i(TAG, "Max recording duration reached")
                finalizeRecording()
            }
            maxDurationHandler.postDelayed(maxDurationRunnable!!, maxMs)

        } catch (e: Exception) {
            Log.e(TAG, "Failed to start recording: ${e.message}")
            voicemailRepository.setProcessing(voicemailId, false)
            stopSelf()
        }
    }

    /**
     * Finalizes the recording — called when call ends (IDLE state) or timeout.
     * Saves metadata to DB and enqueues the transcription worker.
     */
    private fun finalizeRecording() {
        maxDurationRunnable?.let { maxDurationHandler.removeCallbacks(it) }
        silenceRunnable?.let { silenceHandler.removeCallbacks(it) }

        val file = recordingFile ?: run { stopSelf(); return }

        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recorder: ${e.message}")
        }

        val durationMs = System.currentTimeMillis() - recordingStartTime
        val fileSize = file.length()

        serviceScope.launch {
            if (currentVoicemailId > 0) {
                voicemailRepository.updateRecordingMeta(currentVoicemailId, durationMs, fileSize)
                voicemailRepository.setProcessing(currentVoicemailId, false)

                // Enqueue background transcription + AI summary worker
                val workId = TranscriptionWorker.enqueue(
                    context = this@CallAssistantService,
                    voicemailId = currentVoicemailId,
                    filePath = file.absolutePath
                )
                voicemailRepository.setWorkId(currentVoicemailId, workId)

                // Show "new voicemail" notification
                showNewVoicemailNotification(currentVoicemailId)
            }

            // Restore normal audio mode
            val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
            audioManager.mode = AudioManager.MODE_NORMAL
            audioManager.isSpeakerphoneOn = false

            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    // ─── Notifications ───────────────────────────────────────────────────────

    private fun buildRecordingNotification(callerNumber: String): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, CallAssistantService::class.java).apply {
                action = ACTION_CALL_ENDED
            },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, AICallAssistantApp.CHANNEL_RECORDING)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("AI Recording Active")
            .setContentText("Recording voicemail from $callerNumber")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .addAction(R.drawable.ic_stop, "Stop Recording", stopIntent)
            .build()
    }

    private fun buildIncomingCallNotification(callerNumber: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val aiAnswerIntent = PendingIntent.getService(
            this, 1,
            Intent(this, CallAssistantService::class.java).apply {
                action = ACTION_AI_ANSWER_TAPPED
                putExtra(EXTRA_CALLER_NUMBER, callerNumber)
            },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, AICallAssistantApp.CHANNEL_INCOMING_CALL)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle("Incoming Call — $callerNumber")
            .setContentText("Tap 'AI Answer' to let AI handle this call")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setContentIntent(openAppIntent)
            .addAction(R.drawable.ic_ai, "AI Answer", aiAnswerIntent)
            .setAutoCancel(true)
            .build()
    }

    private fun showNewVoicemailNotification(voicemailId: Long) {
        val openIntent = PendingIntent.getActivity(
            this, voicemailId.toInt(),
            Intent(this, MainActivity::class.java).apply {
                action = "com.saiganesh.callassistant.OPEN_VOICEMAIL"
                putExtra("voicemail_id", voicemailId)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, AICallAssistantApp.CHANNEL_VOICEMAIL)
            .setSmallIcon(R.drawable.ic_voicemail)
            .setContentTitle("New Voicemail Saved")
            .setContentText("Tap to listen and view AI summary")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .build()

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(AICallAssistantApp.NOTIF_ID_VOICEMAIL, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        tts?.shutdown()
        mediaRecorder?.release()
        serviceScope.cancel()
        maxDurationRunnable?.let { maxDurationHandler.removeCallbacks(it) }
        silenceRunnable?.let { silenceHandler.removeCallbacks(it) }
    }

    companion object {
        private const val TAG = "CallAssistantService"
        const val ACTION_HANDLE_INCOMING_CALL = "action_handle_incoming_call"
        const val ACTION_SHOW_NOTIFICATION_ONLY = "action_show_notification_only"
        const val ACTION_CALL_ENDED = "action_call_ended"
        const val ACTION_AI_ANSWER_TAPPED = "action_ai_answer_tapped"
        const val EXTRA_CALLER_NUMBER = "extra_caller_number"
        private const val UTTERANCE_ID_GREETING = "greeting"
    }
}
