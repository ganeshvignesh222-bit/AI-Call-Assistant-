package com.saiganesh.callassistant.ui

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.AndroidEntryPoint
import com.saiganesh.callassistant.ui.navigation.AppNavGraph
import com.saiganesh.callassistant.ui.theme.AICallAssistantTheme
import com.saiganesh.callassistant.viewmodel.SettingsViewModel

/**
 * MainActivity — Single-activity host for the entire app.
 *
 * Responsibilities:
 * 1. Splash screen installation (AndroidX SplashScreen API)
 * 2. Edge-to-edge display configuration
 * 3. Runtime permission requests
 * 4. Theme initialization (dark/light/system)
 * 5. Navigation graph setup
 *
 * All UI is rendered via Jetpack Compose. No XML layouts are used.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    // ─── Permission Launcher ──────────────────────────────────────────────────

    /**
     * Requests all permissions needed for the app's core features.
     *
     * Permissions requested:
     * - READ_PHONE_STATE: Detect incoming calls
     * - READ_CALL_LOG: Match caller info from call history
     * - RECORD_AUDIO: Record caller's voicemail
     * - POST_NOTIFICATIONS: Show call/voicemail notifications (Android 13+)
     * - ANSWER_PHONE_CALLS: Attempt auto-answering
     *
     * The permission result is handled gracefully — denied permissions
     * degrade features with clear UI messaging rather than crashing.
     */
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Log results — UI handles each feature's permission state individually
        permissions.forEach { (permission, granted) ->
            android.util.Log.i("MainActivity", "Permission $permission: $granted")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Install splash screen BEFORE super.onCreate()
        installSplashScreen()
        super.onCreate(savedInstanceState)

        // Edge-to-edge display (draws behind status bar and nav bar)
        enableEdgeToEdge()

        // Request all required permissions on first launch
        requestPermissions()

        setContent {
            val settingsViewModel: SettingsViewModel = hiltViewModel()
            val settings by settingsViewModel.settings.collectAsStateWithLifecycle()

            // Determine theme based on user preference
            val isDarkTheme = when (settings.themeMode) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }

            AICallAssistantTheme(darkTheme = isDarkTheme) {
                AppNavGraph(
                    // Pass deep-link voicemail ID if launched from notification
                    initialVoicemailId = intent?.getLongExtra("voicemail_id", -1)
                        ?.takeIf { it > 0 }
                )
            }
        }
    }

    private fun requestPermissions() {
        val permissions = buildList {
            add(Manifest.permission.READ_PHONE_STATE)
            add(Manifest.permission.READ_CALL_LOG)
            add(Manifest.permission.RECORD_AUDIO)
            add(Manifest.permission.ANSWER_PHONE_CALLS)
            // POST_NOTIFICATIONS requires API 33+
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }
}
