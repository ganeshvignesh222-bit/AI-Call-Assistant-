package com.saiganesh.callassistant.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.saiganesh.callassistant.data.local.entities.SettingsEntity
import com.saiganesh.callassistant.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<SettingsEntity> = settingsRepository
        .observeSettings()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = SettingsEntity()
        )

    // API key presence (never expose the actual key to UI)
    val hasGeminiKey: StateFlow<Boolean> = flow {
        emit(settingsRepository.getGeminiApiKey() != null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    val hasOpenAiKey: StateFlow<Boolean> = flow {
        emit(settingsRepository.getOpenAiApiKey() != null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    fun update(block: SettingsEntity.() -> SettingsEntity) = viewModelScope.launch {
        val current = settingsRepository.getSettings()
        settingsRepository.updateSettings(current.block())
    }

    fun setAutoAnswer(enabled: Boolean) = update { copy(autoAnswerEnabled = enabled) }
    fun setGreetingText(text: String) = update { copy(greetingText = text) }
    fun setThemeMode(mode: String) = update { copy(themeMode = mode) }
    fun setAiSummaryEnabled(enabled: Boolean) = update { copy(aiSummaryEnabled = enabled) }
    fun setAutoTranscribe(enabled: Boolean) = update { copy(autoTranscribeEnabled = enabled) }
    fun setMaxRecordingSeconds(seconds: Int) = update { copy(maxRecordingSeconds = seconds) }
    fun setAutoAnswerDelay(seconds: Int) = update { copy(autoAnswerDelaySeconds = seconds) }
    fun setAiProvider(provider: String) = update { copy(aiProvider = provider) }
    fun setPlayBeep(play: Boolean) = update { copy(playBeepBeforeRecording = play) }
    fun setOnlyUnknownCallers(only: Boolean) = update { copy(onlyAnswerUnknownCallers = only) }
    fun setEncryptRecordings(encrypt: Boolean) = update { copy(encryptRecordings = encrypt) }
    fun setCloudBackupEnabled(enabled: Boolean) = update { copy(cloudBackupEnabled = enabled) }
    fun setTtsSpeechRate(rate: Float) = update { copy(ttsSpeechRate = rate) }
    fun setTtsPitch(pitch: Float) = update { copy(ttsPitch = pitch) }
    fun setTtsLanguage(lang: String) = update { copy(ttsLanguage = lang) }

    fun saveGeminiApiKey(key: String) {
        settingsRepository.saveGeminiApiKey(key)
    }

    fun saveOpenAiApiKey(key: String) {
        settingsRepository.saveOpenAiApiKey(key)
    }

    fun clearApiKeys() {
        settingsRepository.clearApiKeys()
    }
}
