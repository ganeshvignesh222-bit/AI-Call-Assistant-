package com.saiganesh.callassistant.utils

import android.content.Context
import android.provider.ContactsContract
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * CallContactHelper — Looks up contact names from the device address book.
 *
 * Requires READ_CONTACTS permission (not declared in manifest by default —
 * add it if you want contact lookup). Without READ_CONTACTS, returns null
 * and the caller number is displayed as-is.
 *
 * Privacy note: Contact lookup is done locally on-device. No data is sent
 * to any server for contact resolution.
 */
@Singleton
class CallContactHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /**
     * Looks up a display name for the given phone number.
     * Returns null if the number is not in contacts or permission is denied.
     */
    fun getContactName(phoneNumber: String): String? {
        if (phoneNumber.isBlank()) return null

        return try {
            val uri = android.net.Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                android.net.Uri.encode(phoneNumber)
            )
            val cursor = context.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    it.getString(it.getColumnIndexOrThrow(ContactsContract.PhoneLookup.DISPLAY_NAME))
                } else null
            }
        } catch (e: SecurityException) {
            // READ_CONTACTS not granted
            null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Returns true if the phone number belongs to a saved contact.
     * Used to decide whether to ring through vs. AI-answer.
     */
    fun isKnownContact(phoneNumber: String): Boolean =
        getContactName(phoneNumber) != null
}
