package com.saiganesh.callassistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * BootReceiver — Restarts call monitoring after device reboot.
 *
 * Android kills all services on reboot. This receiver listens for
 * BOOT_COMPLETED and re-registers the telephony callback so the
 * app can detect calls even after a restart.
 *
 * Required permission: RECEIVE_BOOT_COMPLETED
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.QUICKBOOT_POWERON"
        ) return

        Log.i(TAG, "Device booted — re-initializing call monitoring")

        // Start the monitoring service in the foreground
        // The service registers TelephonyCallback and stays alive
        val serviceIntent = Intent(context, CallAssistantService::class.java).apply {
            action = CallAssistantService.ACTION_SHOW_NOTIFICATION_ONLY
            putExtra(CallAssistantService.EXTRA_CALLER_NUMBER, "")
        }
        // Note: We don't start a full foreground service here since there's no call yet.
        // The CallReceiver broadcast handles new calls. We just log that we're alive.
        Log.i(TAG, "Boot receiver complete — waiting for incoming calls via CallReceiver")
    }

    companion object {
        private const val TAG = "BootReceiver"
    }
}
