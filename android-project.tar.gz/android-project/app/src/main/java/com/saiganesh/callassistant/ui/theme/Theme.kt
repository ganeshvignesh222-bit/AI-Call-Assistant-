package com.saiganesh.callassistant.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// ─── Brand Colors ─────────────────────────────────────────────────────────────

val PrimaryBlue = Color(0xFF1A73E8)        // Google Blue
val PrimaryBlueDark = Color(0xFF4285F4)
val SecondaryTeal = Color(0xFF00BCD4)
val ErrorRed = Color(0xFFD32F2F)
val SuccessGreen = Color(0xFF4CAF50)
val WarningAmber = Color(0xFFFFC107)

// ─── Dark Theme ───────────────────────────────────────────────────────────────

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryBlueDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1565C0),
    onPrimaryContainer = Color(0xFFD1E4FF),
    secondary = SecondaryTeal,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF004D58),
    onSecondaryContainer = Color(0xFFB2EBF2),
    tertiary = WarningAmber,
    background = Color(0xFF0F0F0F),
    onBackground = Color(0xFFE1E1E1),
    surface = Color(0xFF1A1A1A),
    onSurface = Color(0xFFE1E1E1),
    surfaceVariant = Color(0xFF252525),
    onSurfaceVariant = Color(0xFFBDBDBD),
    error = ErrorRed,
    outline = Color(0xFF444444)
)

// ─── Light Theme ──────────────────────────────────────────────────────────────

private val LightColorScheme = lightColorScheme(
    primary = PrimaryBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD1E4FF),
    onPrimaryContainer = Color(0xFF001D36),
    secondary = Color(0xFF0097A7),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFB2EBF2),
    onSecondaryContainer = Color(0xFF001F24),
    tertiary = Color(0xFFF57C00),
    background = Color(0xFFF8FAFE),
    onBackground = Color(0xFF1A1A1A),
    surface = Color.White,
    onSurface = Color(0xFF1A1A1A),
    surfaceVariant = Color(0xFFF1F3F9),
    onSurfaceVariant = Color(0xFF444444),
    error = ErrorRed,
    outline = Color(0xFFBDBDBD)
)

/**
 * AICallAssistantTheme — Material 3 theme with dark/light support.
 *
 * Dynamic color (Material You) is supported on Android 12+ but disabled
 * by default to maintain consistent brand identity. Enable by setting
 * dynamicColor = true.
 *
 * @param darkTheme - force dark or light; defaults to system setting
 * @param dynamicColor - use Android 12+ wallpaper-derived colors
 */
@Composable
fun AICallAssistantTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = androidx.compose.ui.platform.LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    // Update status bar color to match the theme surface
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.surface.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
