package com.saiganesh.callassistant.utils

import android.content.Context
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * EncryptedFileHelper — Wraps EncryptedFile API for reading/writing
 * encrypted audio recordings.
 *
 * Uses AES256-GCM encryption via AndroidX Security library.
 * The key is stored in Android Keystore (hardware-backed when available).
 *
 * Usage:
 *   - Call openEncryptedOutputStream() before recording to get a stream
 *     MediaRecorder can write to.
 *   - Call openEncryptedInputStream() before playback to stream the audio.
 *
 * NOTE: MediaRecorder does NOT support writing directly to an EncryptedFile
 * stream — it requires a real file path. The current implementation stores
 * recordings as standard files in the app's private directory
 * (getExternalFilesDir), which is already protected by Android's
 * file system permissions (not accessible without root on non-rooted devices).
 *
 * For FULL encryption of recordings:
 * - Record to a temp file → encrypt to final file → delete temp file
 * - Or use a custom MediaRecorder + AES cipher stream pipeline
 *
 * This class provides the encrypt/decrypt utilities for the
 * post-recording encryption pass.
 */
@Singleton
class EncryptedFileHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    /**
     * Encrypts a plaintext source file to an encrypted destination file.
     * Deletes the source file after successful encryption.
     *
     * @param source      Raw (unencrypted) file to encrypt
     * @param destination Target encrypted file path
     * @return true if encryption succeeded, false otherwise
     */
    fun encrypt(source: File, destination: File): Boolean {
        return try {
            if (destination.exists()) destination.delete()

            val encryptedFile = EncryptedFile.Builder(
                context,
                destination,
                masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()

            source.inputStream().use { input ->
                encryptedFile.openFileOutput().use { output ->
                    input.copyTo(output)
                }
            }

            source.delete() // Remove plaintext file
            true
        } catch (e: Exception) {
            android.util.Log.e("EncryptedFileHelper", "Encryption failed: ${e.message}")
            false
        }
    }

    /**
     * Opens an encrypted file for reading (decrypts on-the-fly).
     * The caller is responsible for closing the returned InputStream.
     */
    fun openForReading(encryptedFile: File): InputStream? {
        return try {
            EncryptedFile.Builder(
                context,
                encryptedFile,
                masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build().openFileInput()
        } catch (e: Exception) {
            android.util.Log.e("EncryptedFileHelper", "Failed to open encrypted file: ${e.message}")
            null
        }
    }

    /**
     * Decrypts an encrypted file to a temp file for playback.
     * MediaPlayer cannot read from a stream — it needs a file path.
     * Remember to delete the temp file after playback.
     *
     * @return Path to the temp decrypted file, or null on failure
     */
    fun decryptToTemp(encryptedFile: File): File? {
        return try {
            val tempFile = File(context.cacheDir, "playback_${System.currentTimeMillis()}.m4a")
            val inputStream = openForReading(encryptedFile) ?: return null
            inputStream.use { input ->
                tempFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            tempFile
        } catch (e: Exception) {
            android.util.Log.e("EncryptedFileHelper", "Decryption to temp failed: ${e.message}")
            null
        }
    }
}
