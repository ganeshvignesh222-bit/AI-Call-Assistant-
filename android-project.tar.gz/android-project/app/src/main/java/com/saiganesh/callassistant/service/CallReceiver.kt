package com.saiganesh.callassistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import com.saiganesh.callassistant.data.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * CallReceiver — BroadcastReceiver for incoming call detection.
 *
 * Listens for android.intent.action.PHONE_STATE broadcasts.
 *
 * Android Limitation Notes:
 * ─────────────────────────
 * 1. PHONE_STATE broadcast only provides the INBOUND caller number
 *    in the RINGING state (requires READ_PHONE_STATE permission).
 *    The number is no longer provided in the OFFHOOK/IDLE states.
 *
 * 2. On Android 10+ (API 29+), apps can only reliably detect call state
 *    changes via TelephonyManager.listen() or TelephonyCallback (API 31+).
 *    The PHONE_STATE broadcast is still delivered but is subject to
 *    increased restrictions from Android 12+ background start restrictions.
 *
 * 3. Auto-answering: ANSWER_PHONE_CALLS permission is declared, but
 *    TelecomManager.acceptRingingCall() only works reliably when this
 *    app is set as the default phone app. As a third-party app, this
 *    is unreliable. We instead show a high-priority notification with
 *    an "AI Answer" action button.
 *
 * 4. Background execution: The receiver starts a Foreground Service to
 *    ensure continued operation. Directly starting background services
 *    from a broadcast is prohibited on Android 8+.
 */
@AndroidEntryPoint
class CallReceiver : BroadcastReceiver() {

    @Inject
    lateinit var settingsRepository: SettingsRepository

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

        Log.d(TAG, "Call state changed: $state, number: $incomingNumber")

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                // Incoming call detected — check if AI assist is enabled
                scope.launch {
                    val settings = settingsRepository.getSettings()
                    if (settings.autoAnswerEnabled) {
                        handleIncomingCall(context, incomingNumber)
                    } else {
                        // Still show a notification even if auto-answer is off
                        showIncomingCallNotification(context, incomingNumber)
                    }
                }
            }

            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                // Call was answered (either by user or AI)
                Log.d(TAG, "Call answered / off hook")
            }

            TelephonyManager.EXTRA_STATE_IDLE -> {
                // Call ended — stop any active recording service
                Log.d(TAG, "Call ended / idle")
                stopCallAssistantService(context)
            }
        }
    }

    /**
     * Starts the foreground CallAssistantService to handle AI greeting and recording.
     *
     * We must start a FOREGROUND service (not background) because:
     * - Android 8+ prohibits starting background services from receivers
     * - The service needs to keep running for the duration of the call
     * - FOREGROUND_SERVICE_TYPE microphone/phoneCall requires foreground
     */
    private fun handleIncomingCall(context: Context, callerNumber: String?) {
        val serviceIntent = Intent(context, CallAssistantService::class.java).apply {
            action = CallAssistantService.ACTION_HANDLE_INCOMING_CALL
            putExtra(CallAssistantService.EXTRA_CALLER_NUMBER, callerNumber ?: "Unknown")
        }
        context.startForegroundService(serviceIntent)
    }

    /**
     * Shows a notification without starting the full recording service.
     * Used when auto-answer is disabled but user wants call awareness.
     */
    private fun showIncomingCallNotification(context: Context, callerNumber: String?) {
        val serviceIntent = Intent(context, CallAssistantService::class.java).apply {
            action = CallAssistantService.ACTION_SHOW_NOTIFICATION_ONLY
            putExtra(CallAssistantService.EXTRA_CALLER_NUMBER, callerNumber ?: "Unknown")
        }
        context.startForegroundService(serviceIntent)
    }

    /** Sends stop signal to the CallAssistantService when the call ends */
    private fun stopCallAssistantService(context: Context) {
        val serviceIntent = Intent(context, CallAssistantService::class.java).apply {
            action = CallAssistantService.ACTION_CALL_ENDED
        }
        context.startService(serviceIntent)
    }

    companion object {
        private const val TAG = "CallReceiver"
    }
}
