package com.saiganesh.callassistant.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.saiganesh.callassistant.data.local.entities.VoicemailEntity
import com.saiganesh.callassistant.viewmodel.VoicemailViewModel
import java.text.SimpleDateFormat
import java.util.*

/**
 * InboxScreen — Voicemail inbox with search, tabs, and swipe-to-delete.
 *
 * Features:
 * - Search bar that filters by caller name, number, transcription, or AI summary
 * - Tab filter: All / Unread / Starred / AI Answered
 * - Animated list items (staggered entrance, slide-out on delete)
 * - Long-press context menu (star, mark read, delete)
 * - Unread items shown with accent color and bold name
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxScreen(
    onNavigateBack: () -> Unit,
    onNavigateToDetail: (Long) -> Unit,
    viewModel: VoicemailViewModel = hiltViewModel()
) {
    val voicemails by viewModel.voicemails.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val activeFilter by viewModel.activeFilter.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadCount.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Text(
                            text = "Inbox",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        if (voicemails.isNotEmpty()) {
                            IconButton(onClick = { viewModel.deleteAll() }) {
                                Icon(Icons.Default.DeleteSweep, contentDescription = "Delete all")
                            }
                        }
                    }
                )
                // Search bar
                SearchBar(
                    query = searchQuery,
                    onQueryChange = viewModel::setSearchQuery,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
                // Filter tabs
                FilterTabs(
                    activeFilter = activeFilter,
                    unreadCount = unreadCount,
                    onFilterSelected = viewModel::setFilter
                )
            }
        }
    ) { paddingValues ->
        if (voicemails.isEmpty()) {
            EmptyInboxView(
                isSearching = searchQuery.isNotBlank(),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                itemsIndexed(
                    items = voicemails,
                    key = { _, item -> item.id }
                ) { index, voicemail ->
                    AnimatedVisibility(
                        visible = true,
                        enter = fadeIn(tween(300, delayMillis = index * 30)) +
                                slideInVertically(tween(300, delayMillis = index * 30)) { it / 3 }
                    ) {
                        VoicemailListItem(
                            voicemail = voicemail,
                            onClick = { onNavigateToDetail(voicemail.id) },
                            onStar = { viewModel.toggleStar(voicemail.id, voicemail.isStarred) },
                            onDelete = { viewModel.deleteVoicemail(voicemail) },
                            onMarkRead = { viewModel.markAsRead(voicemail.id) }
                        )
                    }
                    if (index < voicemails.lastIndex) {
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 72.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = modifier,
        placeholder = { Text("Search by name, number, or content") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
            if (query.isNotBlank()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(Icons.Default.Close, contentDescription = "Clear")
                }
            }
        },
        singleLine = true,
        shape = MaterialTheme.shapes.extraLarge
    )
}

@Composable
private fun FilterTabs(
    activeFilter: VoicemailViewModel.Filter,
    unreadCount: Int,
    onFilterSelected: (VoicemailViewModel.Filter) -> Unit
) {
    val tabs = listOf(
        Pair(VoicemailViewModel.Filter.ALL, "All"),
        Pair(VoicemailViewModel.Filter.UNREAD, "Unread${if (unreadCount > 0) " ($unreadCount)" else ""}"),
        Pair(VoicemailViewModel.Filter.STARRED, "Starred"),
        Pair(VoicemailViewModel.Filter.AI_ANSWERED, "AI Answered")
    )

    ScrollableTabRow(
        selectedTabIndex = tabs.indexOfFirst { it.first == activeFilter },
        edgePadding = 16.dp,
        divider = {}
    ) {
        tabs.forEach { (filter, label) ->
            Tab(
                selected = activeFilter == filter,
                onClick = { onFilterSelected(filter) },
                text = {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (activeFilter == filter) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VoicemailListItem(
    voicemail: VoicemailEntity,
    onClick: () -> Unit,
    onStar: () -> Unit,
    onDelete: () -> Unit,
    onMarkRead: () -> Unit
) {
    var showContextMenu by remember { mutableStateOf(false) }

    ListItem(
        modifier = Modifier
            .combinedClickable(
                onClick = onClick,
                onLongClick = { showContextMenu = true }
            )
            .background(
                if (!voicemail.isRead)
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.08f)
                else Color.Transparent
            ),
        headlineContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = voicemail.callerName ?: voicemail.callerNumber,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (!voicemail.isRead) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (voicemail.isStarred) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = null,
                        tint = Color(0xFFFFC107),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        },
        supportingContent = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                // AI summary preview OR transcription preview
                val preview = voicemail.aiSummary ?: voicemail.transcription
                if (preview != null) {
                    Text(
                        text = preview,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                } else {
                    Text(
                        text = if (voicemail.isProcessing) "Processing..." else "No transcription",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
            }
        },
        leadingContent = {
            CallerAvatar(
                callerName = voicemail.callerName,
                callerNumber = voicemail.callerNumber,
                isRead = voicemail.isRead
            )
        },
        trailingContent = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = formatTimestamp(voicemail.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = formatDuration(voicemail.durationMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                if (voicemail.wasAiAnswered) {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = MaterialTheme.shapes.extraSmall
                    ) {
                        Text(
                            text = "AI",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    )

    // Context menu on long-press
    DropdownMenu(
        expanded = showContextMenu,
        onDismissRequest = { showContextMenu = false }
    ) {
        DropdownMenuItem(
            text = { Text(if (voicemail.isStarred) "Unstar" else "Star") },
            leadingIcon = {
                Icon(
                    if (voicemail.isStarred) Icons.Default.StarBorder else Icons.Default.Star,
                    contentDescription = null
                )
            },
            onClick = { onStar(); showContextMenu = false }
        )
        if (voicemail.isRead) {
            DropdownMenuItem(
                text = { Text("Mark as Unread") },
                leadingIcon = { Icon(Icons.Default.MarkEmailUnread, contentDescription = null) },
                onClick = { onMarkRead(); showContextMenu = false }
            )
        }
        HorizontalDivider()
        DropdownMenuItem(
            text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
            leadingIcon = {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error
                )
            },
            onClick = { onDelete(); showContextMenu = false }
        )
    }
}

@Composable
private fun CallerAvatar(
    callerName: String?,
    callerNumber: String,
    isRead: Boolean
) {
    val initial = (callerName ?: callerNumber).firstOrNull()?.uppercaseChar() ?: '?'
    val bgColor = if (isRead)
        MaterialTheme.colorScheme.surfaceVariant
    else
        MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initial.toString(),
            style = MaterialTheme.typography.titleMedium,
            color = if (isRead)
                MaterialTheme.colorScheme.onSurfaceVariant
            else
                MaterialTheme.colorScheme.onPrimary,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun EmptyInboxView(isSearching: Boolean, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (isSearching) Icons.Default.SearchOff else Icons.Default.VoicemailOutlined,
            contentDescription = null,
            modifier = Modifier.size(80.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = if (isSearching) "No results found" else "No voicemails yet",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = if (isSearching) "Try a different search term" else "When AI handles a call, voicemails appear here",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
        )
    }
}

private fun formatTimestamp(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - timestamp
    return when {
        diff < 60_000 -> "Just now"
        diff < 3_600_000 -> "${diff / 60_000}m ago"
        diff < 86_400_000 -> "${diff / 3_600_000}h ago"
        diff < 604_800_000 -> SimpleDateFormat("EEE", Locale.getDefault()).format(Date(timestamp))
        else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(timestamp))
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return if (minutes > 0) "${minutes}m ${seconds}s" else "${seconds}s"
}
