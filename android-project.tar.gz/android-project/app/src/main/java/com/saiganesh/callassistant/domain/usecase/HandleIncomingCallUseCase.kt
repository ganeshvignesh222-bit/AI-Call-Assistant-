package com.saiganesh.callassistant.domain.usecase

import android.content.Context
import android.content.Intent
import com.saiganesh.callassistant.data.repository.SettingsRepository
import com.saiganesh.callassistant.service.CallAssistantService
import com.saiganesh.callassistant.utils.CallContactHelper
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

/**
 * HandleIncomingCallUseCase — Encapsulates the business logic for deciding
 * what to do when an incoming call is detected.
 *
 * Decision tree:
 * 1. Is AI auto-answer enabled? If not → show awareness notification only.
 * 2. Is it a known contact AND onlyAnswerUnknownCallers = true? → ring through.
 * 3. Is the number blocked? → ignore completely.
 * 4. Otherwise → start CallAssistantService to handle AI greeting + recording.
 *
 * This use case keeps the CallReceiver thin and testable.
 */
class HandleIncomingCallUseCase @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val contactHelper: CallContactHelper
) {

    suspend operator fun invoke(callerNumber: String) {
        val settings = settingsRepository.getSettings()

        // Check if number is blocked
        val blockedNumbers = settings.blockedNumbers
            .split(",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
        if (callerNumber in blockedNumbers) {
            android.util.Log.i("HandleIncomingCall", "Blocked number: $callerNumber — ignoring")
            return
        }

        // If only answering unknown callers, check contacts
        if (settings.onlyAnswerUnknownCallers) {
            val isKnown = contactHelper.isKnownContact(callerNumber)
            if (isKnown) {
                android.util.Log.i("HandleIncomingCall", "Known contact — ringing through: $callerNumber")
                return
            }
        }

        val action = if (settings.autoAnswerEnabled) {
            CallAssistantService.ACTION_HANDLE_INCOMING_CALL
        } else {
            CallAssistantService.ACTION_SHOW_NOTIFICATION_ONLY
        }

        val serviceIntent = Intent(context, CallAssistantService::class.java).apply {
            this.action = action
            putExtra(CallAssistantService.EXTRA_CALLER_NUMBER, callerNumber)
        }
        context.startForegroundService(serviceIntent)
    }
}
