package com.saiganesh.callassistant.ui.screens

import android.content.Intent
import android.media.MediaPlayer
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.saiganesh.callassistant.data.local.entities.VoicemailEntity
import com.saiganesh.callassistant.viewmodel.VoicemailViewModel
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * VoicemailDetailScreen — Full detail view for a single voicemail.
 *
 * Features:
 * - Audio player with seek bar and playback controls
 * - AI summary card (with shimmer while processing)
 * - Full transcription section (expandable)
 * - Caller info and call metadata
 * - Share, star, and delete actions
 *
 * Audio playback uses Android MediaPlayer.
 * Seek position updates every 500ms via a coroutine.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoicemailDetailScreen(
    voicemailId: Long,
    onNavigateBack: () -> Unit,
    viewModel: VoicemailViewModel = hiltViewModel()
) {
    val context = LocalContext.current

    LaunchedEffect(voicemailId) {
        viewModel.selectVoicemail(voicemailId)
    }

    val voicemail by viewModel.selectedVoicemail.collectAsStateWithLifecycle()

    // MediaPlayer state
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playbackPosition by remember { mutableStateOf(0) }
    var playbackDuration by remember { mutableStateOf(1) }

    // Update playback position while playing
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            playbackPosition = mediaPlayer?.currentPosition ?: 0
            delay(500)
        }
    }

    DisposableEffect(voicemailId) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Voicemail") },
                navigationIcon = {
                    IconButton(onClick = {
                        mediaPlayer?.release()
                        onNavigateBack()
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    voicemail?.let { vm ->
                        IconButton(onClick = { viewModel.toggleStar(vm.id, vm.isStarred) }) {
                            Icon(
                                if (vm.isStarred) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = "Star",
                                tint = if (vm.isStarred) Color(0xFFFFC107)
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = {
                            shareVoicemail(context, vm)
                        }) {
                            Icon(Icons.Default.Share, contentDescription = "Share")
                        }
                        IconButton(onClick = {
                            viewModel.deleteVoicemail(vm)
                            onNavigateBack()
                        }) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        voicemail?.let { vm ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Caller info card
                CallerInfoCard(voicemail = vm)

                // Audio player
                AudioPlayerCard(
                    voicemail = vm,
                    isPlaying = isPlaying,
                    playbackPosition = playbackPosition,
                    playbackDuration = playbackDuration,
                    onPlayPause = {
                        if (isPlaying) {
                            mediaPlayer?.pause()
                            isPlaying = false
                        } else {
                            if (mediaPlayer == null) {
                                try {
                                    mediaPlayer = MediaPlayer().apply {
                                        setDataSource(vm.recordingFilePath)
                                        prepare()
                                        playbackDuration = duration.coerceAtLeast(1)
                                        setOnCompletionListener {
                                            isPlaying = false
                                            playbackPosition = 0
                                            seekTo(0)
                                        }
                                    }
                                } catch (e: Exception) {
                                    android.util.Log.e("Detail", "MediaPlayer error: ${e.message}")
                                }
                            }
                            mediaPlayer?.start()
                            isPlaying = true
                        }
                    },
                    onSeek = { position ->
                        mediaPlayer?.seekTo(position)
                        playbackPosition = position
                    }
                )

                // AI Summary card
                AiSummaryCard(voicemail = vm)

                // Transcription
                TranscriptionCard(voicemail = vm)

                // Metadata
                MetadataCard(voicemail = vm)
            }
        } ?: Box(
            modifier = Modifier.fillMaxSize().padding(paddingValues),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
    }
}

@Composable
private fun CallerInfoCard(voicemail: VoicemailEntity) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                val initial = (voicemail.callerName ?: voicemail.callerNumber)
                    .firstOrNull()?.uppercaseChar() ?: '?'
                Text(
                    text = initial.toString(),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = voicemail.callerName ?: "Unknown Caller",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = voicemail.callerNumber,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = SimpleDateFormat("EEEE, MMM d · h:mm a", Locale.getDefault())
                        .format(Date(voicemail.timestamp)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (voicemail.wasAiAnswered) {
                    Spacer(modifier = Modifier.height(4.dp))
                    AssistChip(
                        onClick = {},
                        label = { Text("Handled by AI", style = MaterialTheme.typography.labelSmall) },
                        leadingIcon = {
                            Icon(Icons.Default.SmartToy, contentDescription = null,
                                modifier = Modifier.size(14.dp))
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AudioPlayerCard(
    voicemail: VoicemailEntity,
    isPlaying: Boolean,
    playbackPosition: Int,
    playbackDuration: Int,
    onPlayPause: () -> Unit,
    onSeek: (Int) -> Unit
) {
    val progress = if (playbackDuration > 0) playbackPosition.toFloat() / playbackDuration else 0f

    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Recording",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Waveform visualizer placeholder
            WaveformVisualizer(isPlaying = isPlaying, progress = progress)

            Spacer(modifier = Modifier.height(8.dp))

            // Seek bar
            Slider(
                value = progress,
                onValueChange = { onSeek((it * playbackDuration).toInt()) },
                modifier = Modifier.fillMaxWidth()
            )

            // Time display
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatMs(playbackPosition.toLong()),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = formatMs(voicemail.durationMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Play/Pause button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                val fileExists = File(voicemail.recordingFilePath).exists()
                FilledIconButton(
                    onClick = onPlayPause,
                    enabled = fileExists,
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            if (!File(voicemail.recordingFilePath).exists()) {
                Text(
                    text = "Recording file not found",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}

/**
 * Animated waveform bars — purely visual indicator of audio activity.
 * Bars animate at varying heights when playing.
 */
@Composable
private fun WaveformVisualizer(isPlaying: Boolean, progress: Float) {
    val barCount = 30
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(barCount) { index ->
            val barProgress = index.toFloat() / barCount
            val isBeforePlayhead = barProgress <= progress

            val animatedHeight by animateFloatAsState(
                targetValue = if (isPlaying) {
                    (0.3f + Math.random().toFloat() * 0.7f) * 48f
                } else {
                    (0.2f + (index % 5) * 0.1f) * 48f
                },
                animationSpec = if (isPlaying)
                    infiniteRepeatable(tween(150 + index * 10), RepeatMode.Reverse)
                else spring(),
                label = "bar_$index"
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(animatedHeight.coerceIn(4f, 48f).dp)
                    .clip(MaterialTheme.shapes.extraSmall)
                    .background(
                        if (isBeforePlayhead) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
            )
        }
    }
}

@Composable
private fun AiSummaryCard(voicemail: VoicemailEntity) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "AI Summary",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            when {
                voicemail.isProcessing -> {
                    // Shimmer loading effect
                    repeat(3) {
                        ShimmerLine(width = if (it == 2) 0.6f else 1f)
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                }
                voicemail.aiSummary != null -> {
                    Text(
                        text = voicemail.aiSummary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                else -> {
                    Text(
                        text = "No AI summary — add a Gemini or OpenAI API key in Settings to enable.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun TranscriptionCard(voicemail: VoicemailEntity) {
    var expanded by remember { mutableStateOf(false) }

    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.Transcribe,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Transcription",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (expanded) "Collapse" else "Expand"
                    )
                }
            }

            AnimatedVisibility(visible = expanded) {
                Text(
                    text = voicemail.transcription
                        ?: "No transcription available. Configure Google Cloud Speech-to-Text in Settings.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (voicemail.transcription != null)
                        MaterialTheme.colorScheme.onSurface
                    else
                        MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            if (!expanded && voicemail.transcription != null) {
                Text(
                    text = voicemail.transcription.take(120) + if (voicemail.transcription.length > 120) "..." else "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun MetadataCard(voicemail: VoicemailEntity) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "Details",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            MetaRow("Duration", formatMs(voicemail.durationMs))
            MetaRow("File Size", formatBytes(voicemail.fileSizeBytes))
            if (voicemail.detectedLanguage != null) {
                MetaRow("Language", voicemail.detectedLanguage)
            }
            MetaRow("Status", if (voicemail.isRead) "Read" else "Unread")
            MetaRow(
                "Encrypted",
                if (File(voicemail.recordingFilePath).exists()) "Yes (local)" else "File missing"
            )
        }
    }
}

@Composable
private fun MetaRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun ShimmerLine(width: Float = 1f) {
    val shimmerTransition = rememberInfiniteTransition(label = "shimmer")
    val alpha by shimmerTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "shimmerAlpha"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth(width)
            .height(14.dp)
            .clip(MaterialTheme.shapes.extraSmall)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = alpha))
    )
}

private fun shareVoicemail(context: android.content.Context, voicemail: VoicemailEntity) {
    val text = buildString {
        append("Voicemail from ${voicemail.callerName ?: voicemail.callerNumber}\n")
        append("Date: ${SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(voicemail.timestamp))}\n")
        if (voicemail.aiSummary != null) append("\nAI Summary:\n${voicemail.aiSummary}\n")
        if (voicemail.transcription != null) append("\nTranscription:\n${voicemail.transcription}")
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
        putExtra(Intent.EXTRA_SUBJECT, "Voicemail from ${voicemail.callerName ?: voicemail.callerNumber}")
    }
    context.startActivity(Intent.createChooser(intent, "Share Voicemail"))
}

private fun formatMs(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    else -> "%.1f MB".format(bytes / (1024.0 * 1024))
}
