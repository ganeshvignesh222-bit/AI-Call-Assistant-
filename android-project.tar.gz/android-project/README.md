# AI Call Assistant — Android Studio Project

A professional Android application that uses AI to handle incoming calls, record voicemails, transcribe speech, and generate AI summaries.

---

## How to Open in Android Studio

1. Open **Android Studio** (Hedgehog 2023.1.1 or later)
2. Click **File → Open** and select the `android-project/` directory
3. Wait for Gradle sync to complete
4. Connect a physical Android device (API 29+) or create an AVD emulator

---

## Project Structure

```
android-project/
├── app/src/main/
│   ├── AndroidManifest.xml          — Permissions + component declarations
│   ├── java/com/saiganesh/callassistant/
│   │   ├── AICallAssistantApp.kt    — Application class, Hilt + notification channels
│   │   ├── data/
│   │   │   ├── local/
│   │   │   │   ├── AppDatabase.kt   — Room DB with SQLCipher encryption
│   │   │   │   ├── dao/             — Data access objects (VoicemailDao, SettingsDao)
│   │   │   │   └── entities/        — VoicemailEntity, SettingsEntity
│   │   │   └── repository/          — VoicemailRepository, SettingsRepository
│   │   ├── domain/
│   │   │   ├── model/               — DashboardStats
│   │   │   └── usecase/             — HandleIncomingCallUseCase
│   │   ├── di/                      — AppModule (Hilt providers)
│   │   ├── service/
│   │   │   ├── CallAssistantService.kt  — Core foreground service (TTS + recording)
│   │   │   ├── CallReceiver.kt          — Broadcast receiver for PHONE_STATE
│   │   │   └── BootReceiver.kt          — Restart after device reboot
│   │   ├── workers/
│   │   │   └── TranscriptionWorker.kt   — WorkManager job for transcription + AI summary
│   │   ├── utils/
│   │   │   ├── AiSummaryClient.kt       — Gemini / OpenAI API client
│   │   │   ├── SpeechTranscriber.kt     — Speech-to-text wrapper
│   │   │   ├── EncryptedFileHelper.kt   — AES-256-GCM file encryption
│   │   │   └── CallContactHelper.kt     — Contact lookup
│   │   ├── viewmodel/               — DashboardViewModel, VoicemailViewModel, SettingsViewModel
│   │   └── ui/
│   │       ├── MainActivity.kt      — Single-activity host, permission requests
│   │       ├── navigation/          — Compose navigation graph + routes
│   │       ├── screens/             — Dashboard, Inbox, Detail, Settings, Permissions
│   │       └── theme/               — Material 3 theme, typography, shapes
│   └── res/
│       ├── values/                  — strings.xml, colors.xml, themes.xml
│       ├── drawable/                — Vector icons
│       └── xml/                     — Backup rules, data extraction rules, file provider
└── app/src/test/                    — Unit tests (VoicemailRepositoryTest)
```

---

## Quick Setup

### 1. Add SQLCipher dependency (required for DB encryption)

In `app/build.gradle.kts`, add:
```kotlin
implementation("net.zetetic:android-database-sqlcipher:4.5.4")
implementation("androidx.sqlite:sqlite-ktx:2.4.0")
```

### 2. Add launcher icons

Replace the placeholder drawables in `res/mipmap-*/` with your actual app icon.
Use Android Studio's **Image Asset Studio** (right-click `res` → New → Image Asset).

### 3. Configure AI summaries (optional)

- Get a free **Gemini API key** at https://aistudio.google.com/
- OR get an **OpenAI API key** at https://platform.openai.com/
- Enter the key in **Settings → AI Features** after launching the app
- Keys are stored in Android Keystore-backed EncryptedSharedPreferences

### 4. Set as Default Phone App (for full auto-answer)

1. Go to **Settings → Default Apps → Phone app**
2. Select **AI Call Assistant**
3. This grants full `ANSWER_PHONE_CALLS` and enables true auto-answering

### 5. Firebase (optional cloud features)

1. Create a Firebase project at https://console.firebase.google.com/
2. Add your Android app with package name `com.saiganesh.callassistant`
3. Download `google-services.json` and place in `app/`
4. Uncomment the Firebase plugin in `build.gradle.kts` files

---

## Android API Limitations

| Feature | Status | Explanation |
|---|---|---|
| Detect incoming calls | ✅ Full | `TelephonyManager` + `PHONE_STATE` broadcast |
| Show notification with "AI Answer" button | ✅ Full | `NotificationManager` high-priority channel |
| Play TTS greeting through speaker | ✅ Full | `TextToSpeech` + speaker routing |
| Record caller's voice (microphone) | ✅ Full | `MediaRecorder` with `AUDIO_SOURCE_MIC` |
| Speech-to-text transcription | ✅ Partial | On-device needs cloud API for file input |
| AI summary generation | ✅ Full | Gemini/OpenAI REST API |
| Auto-answer calls | ⚠️ Limited | Requires default Phone app role on Android 10+ |
| Inject TTS audio INTO call | ❌ Impossible | No public Android API for telephony audio injection |
| Record remote party audio | ❌ Blocked | Restricted since Android 10 on most OEMs |

---

## Permissions Explained

All permissions are declared in `AndroidManifest.xml` with inline documentation.
The app only requests what it actually uses, and degrades gracefully when denied.

---

## Running Unit Tests

```bash
./gradlew test
```

---

## Build for Release

```bash
./gradlew assembleRelease
```

Sign the APK with your keystore before distributing.
